import {
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  ShieldAlert,
  UserCheck,
  X,
} from 'lucide-react';
import React, { useCallback, useEffect, useState } from 'react';
import {
  AppointmentStatusIndicator,
  DoctorStatusIndicator,
} from '../components/StatusBadge';
import { useAppContext } from '../context/AppContext';
import type {
  AuditLogItem,
  Clinic,
  DoctorSessionStatus,
  QueueAppointmentItem,
} from '../types';

interface StaffSessionBoard {
  session: {
    id: string;
    session_date: string;
    period: 'morning' | 'evening';
    start_time: string;
    end_time: string;
    status: DoctorSessionStatus;
    delay_minutes: number;
  };
  doctor: {
    id: string;
    name: string;
    specialty: string;
    room_number: string;
  };
  clinic: Clinic;
  ewmaMinutes: number;
  currentTokenNumber: number | null;
  waitingCount: number;
  completedCount: number;
  skippedCount: number;
  waitingPatients: QueueAppointmentItem[];
}

export function StaffOverviewPage() {
  const { subscribeUpdates, triggerLocalRefresh } = useAppContext();

  const [clinics, setClinics] = useState<Clinic[]>([]);
  const [boards, setBoards] = useState<StaffSessionBoard[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>([]);
  const [selectedClinicId, setSelectedClinicId] = useState('all');
  const [expandedSessionId, setExpandedSessionId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const [feedback, setFeedback] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  const [escalateBoard, setEscalateBoard] = useState<StaffSessionBoard | null>(null);
  const [escalateForm, setEscalateForm] = useState({
    staffName: 'Nina Alvarez (Charge Coordinator)',
    patientName: '',
    patientPhone: '',
    reason: '',
    confirmed: false,
  });
  const [submitting, setSubmitting] = useState(false);

  const loadOverview = useCallback(async () => {
    try {
      const res = await fetch(
        `/api/staff/overview?clinicId=${encodeURIComponent(selectedClinicId)}`
      );
      const data = await res.json();
      setClinics(data.clinics || []);
      setBoards(data.sessionBoards || []);
      setAuditLogs(data.auditLogs || []);
    } catch {
      setFeedback({ type: 'error', text: 'Unable to load clinic overview.' });
    } finally {
      setLoading(false);
    }
  }, [selectedClinicId]);

  useEffect(() => {
    setLoading(true);
    loadOverview();
    const unsub = subscribeUpdates(() => {
      loadOverview();
    });
    return unsub;
  }, [loadOverview, subscribeUpdates]);

  const handleStaffCheckIn = async (apptId: string, tokenNum: number) => {
    setFeedback(null);
    try {
      const res = await fetch(`/api/appointments/${apptId}/checkin`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode: 'manual', actorRole: 'staff' }),
      });
      const data = await res.json();
      if (!res.ok) {
        setFeedback({ type: 'error', text: data.error || 'Check-in failed.' });
        return;
      }
      setFeedback({
        type: 'success',
        text: `Token #${tokenNum} marked Checked In at the clinic desk.`,
      });
      triggerLocalRefresh();
    } catch {
      setFeedback({ type: 'error', text: 'Network error during check-in.' });
    }
  };

  const handleEscalateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!escalateBoard) return;
    setSubmitting(true);
    setFeedback(null);
    try {
      const res = await fetch(
        `/api/staff/sessions/${escalateBoard.session.id}/escalate`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(escalateForm),
        }
      );
      const data = await res.json();
      if (!res.ok) {
        setFeedback({ type: 'error', text: data.error || 'Escalation failed.' });
        return;
      }
      setFeedback({
        type: 'success',
        text: `Authorized urgent escalation recorded: Token #${data.tokenNumber} placed ahead in ${escalateBoard.doctor.name}’s queue. All affected wait estimates recalculated.`,
      });
      setEscalateBoard(null);
      setEscalateForm({
        staffName: 'Nina Alvarez (Charge Coordinator)',
        patientName: '',
        patientPhone: '',
        reason: '',
        confirmed: false,
      });
      triggerLocalRefresh();
    } catch {
      setFeedback({ type: 'error', text: 'Network error during escalation.' });
    } finally {
      setSubmitting(false);
    }
  };

  const totalWaiting = boards.reduce((sum, b) => sum + b.waitingCount, 0);
  const delayedOrBreakCount = boards.filter(
    (b) => b.session.status !== 'in_consultation' || b.session.delay_minutes > 0
  ).length;

  const formatTime = (iso: string) => {
    try {
      return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch {
      return '';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header & Clinic Filter */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Clinic Staff Operations Desk</h1>
          <p className="text-sm text-slate-600 mt-1">
            Branch-wide live queue status, front-desk check-in assistance, and audited urgent escalations.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <label htmlFor="staff-clinic-filter" className="text-xs font-medium text-slate-600">
            Filter branch:
          </label>
          <select
            id="staff-clinic-filter"
            value={selectedClinicId}
            onChange={(e) => setSelectedClinicId(e.target.value)}
            className="px-3.5 py-2 rounded-lg border border-slate-300 bg-white text-sm font-medium text-slate-900 focus:border-teal-700 focus:outline-none"
          >
            <option value="all">All 4 City Branches</option>
            {clinics.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {feedback && (
        <div
          role="status"
          className={`p-4 rounded-xl border text-sm flex items-center justify-between gap-4 ${
            feedback.type === 'error'
              ? 'bg-rose-50 border-rose-200 text-rose-900'
              : 'bg-emerald-50 border-emerald-200 text-emerald-900'
          }`}
        >
          <span>{feedback.text}</span>
          <button
            type="button"
            onClick={() => setFeedback(null)}
            aria-label="Dismiss message"
            className="p-1 rounded hover:bg-black/5 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Clinic Summary Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs text-slate-500">Sessions Monitored Today</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 mt-1">
            {boards.length}
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs text-slate-500">Total Patients Waiting</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 mt-1">
            {totalWaiting}
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs text-slate-500">Sessions Delayed or On Break</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-amber-800 mt-1">
            {delayedOrBreakCount}
          </div>
        </div>
      </div>

      {/* Active Sessions Table & Expandable Check-in */}
      <section aria-labelledby="staff-sessions-heading" className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <h2 id="staff-sessions-heading" className="text-xl font-semibold text-slate-900">
            Active & Upcoming Clinic Sessions
          </h2>
          <span className="text-xs text-slate-500 flex items-center gap-1.5">
            <ShieldAlert className="w-4 h-4 text-amber-700" aria-hidden="true" />
            <span>Urgent escalation is a demo administrative workflow, not clinical triage guidance.</span>
          </span>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl divide-y divide-slate-200">
          {loading ? (
            <div className="p-10 h-48 animate-pulse" />
          ) : (
            boards.map((board) => {
              const isExpanded = expandedSessionId === board.session.id;
              return (
                <div key={board.session.id} className="p-5 space-y-4">
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2.5">
                        <h3 className="text-base font-semibold text-slate-900">
                          {board.doctor.name}
                        </h3>
                        <DoctorStatusIndicator
                          status={board.session.status}
                          delayMinutes={board.session.delay_minutes}
                        />
                      </div>
                      <p className="text-xs text-slate-600">
                        {board.doctor.specialty} · {board.clinic.name} · {board.doctor.room_number} ·{' '}
                        {board.session.period === 'morning' ? 'Morning' : 'Evening'} (
                        {board.session.start_time}–{board.session.end_time})
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-6 text-xs">
                      <div>
                        <div className="text-slate-500">Serving</div>
                        <div className="font-mono tabular-nums text-sm font-semibold text-slate-900">
                          {board.currentTokenNumber ? `#${board.currentTokenNumber}` : 'Ready'}
                        </div>
                      </div>
                      <div>
                        <div className="text-slate-500">Waiting</div>
                        <div className="font-mono tabular-nums text-sm font-semibold text-slate-900">
                          {board.waitingCount}
                        </div>
                      </div>
                      <div>
                        <div className="text-slate-500">EWMA Pace</div>
                        <div className="font-mono tabular-nums text-sm font-semibold text-teal-800">
                          {board.ewmaMinutes}m
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() =>
                            setExpandedSessionId((prev) =>
                              prev === board.session.id ? null : board.session.id
                            )
                          }
                          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-300 text-xs font-medium text-slate-800 hover:bg-slate-50 cursor-pointer"
                        >
                          <span>Check-In Desk ({board.waitingCount})</span>
                          {isExpanded ? (
                            <ChevronUp className="w-3.5 h-3.5" />
                          ) : (
                            <ChevronDown className="w-3.5 h-3.5" />
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={() => setEscalateBoard(board)}
                          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-rose-200 bg-rose-50 text-rose-800 text-xs font-semibold hover:bg-rose-100 cursor-pointer"
                        >
                          <AlertTriangle className="w-3.5 h-3.5" aria-hidden="true" />
                          <span>Urgent Escalation</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {isExpanded && (
                    <div className="pt-3 border-t border-slate-200">
                      {board.waitingPatients.length === 0 ? (
                        <p className="text-xs text-slate-500 py-2">
                          No patients currently waiting in this session.
                        </p>
                      ) : (
                        <div className="overflow-x-auto">
                          <table className="w-full text-left border-collapse text-xs">
                            <thead>
                              <tr className="border-b border-slate-200 text-slate-500">
                                <th className="py-2 pr-4 font-medium">Token</th>
                                <th className="py-2 px-4 font-medium">Patient</th>
                                <th className="py-2 px-4 font-medium">Status</th>
                                <th className="py-2 px-4 font-medium text-right">Est. Wait</th>
                                <th className="py-2 pl-4 font-medium text-right">Desk Action</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                              {board.waitingPatients.map((pt) => (
                                <tr key={pt.id}>
                                  <td className="py-2.5 pr-4 font-mono tabular-nums font-semibold text-slate-900">
                                    #{pt.token_number}
                                  </td>
                                  <td className="py-2.5 px-4 font-medium text-slate-900">
                                    {pt.patientName}{' '}
                                    <span className="text-slate-500 font-mono font-normal">
                                      ({pt.patientPhoneMasked})
                                    </span>
                                  </td>
                                  <td className="py-2.5 px-4">
                                    <AppointmentStatusIndicator
                                      status={pt.status}
                                      isUrgent={pt.is_urgent === 1}
                                    />
                                  </td>
                                  <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-700">
                                    ~{pt.estimatedWaitMinutes ?? 0}m
                                  </td>
                                  <td className="py-2.5 pl-4 text-right">
                                    {pt.status === 'waiting' ? (
                                      <button
                                        type="button"
                                        onClick={() =>
                                          handleStaffCheckIn(pt.id, pt.token_number)
                                        }
                                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-slate-900 text-white font-medium hover:bg-slate-800 cursor-pointer"
                                      >
                                        <UserCheck className="w-3 h-3" aria-hidden="true" />
                                        <span>Assist Check-In</span>
                                      </button>
                                    ) : (
                                      <span className="text-emerald-700 font-medium">
                                        Checked In
                                      </span>
                                    )}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </section>

      {/* Clinic-Wide Audit Trail */}
      <section aria-labelledby="audit-trail-heading" className="space-y-4">
        <h2 id="audit-trail-heading" className="text-xl font-semibold text-slate-900">
          Queue & Escalation Audit Log
        </h2>
        <div className="bg-white border border-slate-200 rounded-xl divide-y divide-slate-200">
          {auditLogs.map((log) => (
            <div
              key={log.id}
              className="px-5 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
            >
              <div className="space-y-0.5">
                <div className="text-slate-900">
                  <span className="font-semibold">{log.actor_name}</span>
                  <span className="text-slate-400 mx-1.5">·</span>
                  <span className="text-slate-600">
                    {log.doctor_name} ({log.clinic_name})
                  </span>
                </div>
                <p className="text-slate-700">{log.details}</p>
              </div>
              <span className="font-mono tabular-nums text-slate-500 shrink-0">
                {formatTime(log.created_at)}
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* Authorized Urgent-Patient Escalation Modal */}
      {escalateBoard && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
          aria-labelledby="escalate-modal-title"
        >
          <form
            onSubmit={handleEscalateSubmit}
            className="bg-white border border-slate-200 rounded-xl max-w-lg w-full p-6 space-y-4 shadow-xl my-auto"
          >
            <div className="flex items-start justify-between gap-4 pb-3 border-b border-slate-200">
              <div>
                <h3 id="escalate-modal-title" className="text-base font-semibold text-slate-900">
                  Authorized Urgent-Patient Escalation
                </h3>
                <p className="text-xs text-slate-600 mt-0.5">
                  Target: {escalateBoard.doctor.name} ({escalateBoard.clinic.name} ·{' '}
                  {escalateBoard.session.period})
                </p>
              </div>
              <button
                type="button"
                onClick={() => setEscalateBoard(null)}
                aria-label="Close escalation dialog"
                className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 text-xs text-amber-900">
              Demo workflow only: Places an urgent token ahead of standard waiting tokens, records an immutable audit entry, and recalculates wait estimates for all affected patients.
            </div>

            <div className="space-y-3">
              <div>
                <label htmlFor="esc-staff-name" className="block text-xs font-semibold text-slate-700 mb-1">
                  Authorizing Staff Member
                </label>
                <input
                  id="esc-staff-name"
                  type="text"
                  required
                  value={escalateForm.staffName}
                  onChange={(e) =>
                    setEscalateForm((p) => ({ ...p, staffName: e.target.value }))
                  }
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:border-teal-700 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="esc-pat-name" className="block text-xs font-semibold text-slate-700 mb-1">
                    Patient Full Name
                  </label>
                  <input
                    id="esc-pat-name"
                    type="text"
                    required
                    value={escalateForm.patientName}
                    onChange={(e) =>
                      setEscalateForm((p) => ({ ...p, patientName: e.target.value }))
                    }
                    placeholder="e.g. Kabir Rao"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:border-teal-700 focus:outline-none"
                  />
                </div>
                <div>
                  <label htmlFor="esc-pat-phone" className="block text-xs font-semibold text-slate-700 mb-1">
                    Contact Phone
                  </label>
                  <input
                    id="esc-pat-phone"
                    type="tel"
                    required
                    value={escalateForm.patientPhone}
                    onChange={(e) =>
                      setEscalateForm((p) => ({ ...p, patientPhone: e.target.value }))
                    }
                    placeholder="555-882-1900"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm font-mono focus:border-teal-700 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="esc-reason" className="block text-xs font-semibold text-slate-700 mb-1">
                  Recorded Escalation Reason (required for audit)
                </label>
                <textarea
                  id="esc-reason"
                  rows={2}
                  required
                  minLength={5}
                  value={escalateForm.reason}
                  onChange={(e) =>
                    setEscalateForm((p) => ({ ...p, reason: e.target.value }))
                  }
                  placeholder="e.g. Post-operative suture complication verified by nurse coordinator"
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:border-teal-700 focus:outline-none"
                />
              </div>

              <label className="flex items-start gap-2.5 text-xs text-slate-700 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  required
                  checked={escalateForm.confirmed}
                  onChange={(e) =>
                    setEscalateForm((p) => ({ ...p, confirmed: e.target.checked }))
                  }
                  className="mt-0.5 rounded border-slate-300 text-teal-700 focus:ring-teal-700"
                />
                <span>
                  I confirm this priority placement is authorized and understand it will adjust estimated wait times for queued patients.
                </span>
              </label>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setEscalateBoard(null)}
                className="px-4 py-2 rounded-lg border border-slate-300 text-sm font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="px-4 py-2 rounded-lg bg-rose-700 text-white text-sm font-semibold hover:bg-rose-800 disabled:opacity-60 cursor-pointer"
              >
                {submitting ? 'Escalating...' : 'Confirm Urgent Escalation'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
