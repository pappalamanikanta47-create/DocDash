import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Coffee,
  FileText,
  Play,
  RotateCcw,
  Stethoscope,
  UserX,
  X,
} from 'lucide-react';
import React, { useCallback, useEffect, useState } from 'react';
import {
  AppointmentStatusIndicator,
  DoctorStatusIndicator,
} from '../components/StatusBadge';
import { useAppContext } from '../context/AppContext';
import type {
  AuditLogItem,
  Clinic,
  DoctorSessionStatus,
  QueueAppointmentItem,
} from '../types';

interface DoctorOption {
  id: string;
  name: string;
  specialty: string;
  clinic_name: string;
  room_number: string;
}

interface SessionOption {
  id: string;
  session_date: string;
  period: 'morning' | 'evening';
  start_time: string;
  end_time: string;
  status: DoctorSessionStatus;
  delay_minutes: number;
}

interface ActiveQueuePayload {
  session: SessionOption & { updated_at: string };
  doctor: {
    id: string;
    name: string;
    specialty: string;
    room_number: string;
    historical_avg_minutes: number;
  };
  clinic: Clinic;
  ewmaMinutes: number;
  currentTokenNumber: number | null;
  activeAppointment: QueueAppointmentItem | null;
  waitingList: QueueAppointmentItem[];
  completedList: QueueAppointmentItem[];
  skippedList: QueueAppointmentItem[];
  recentDurations: Array<{ duration_minutes: number; created_at: string }>;
  auditLogs: AuditLogItem[];
}

export function DoctorConsolePage() {
  const { activeDoctorId, setActiveDoctorId, subscribeUpdates, triggerLocalRefresh } =
    useAppContext();

  const [doctors, setDoctors] = useState<DoctorOption[]>([]);
  const [sessions, setSessions] = useState<SessionOption[]>([]);
  const [selectedSessionId, setSelectedSessionId] = useState<string>('');
  const [activeQueue, setActiveQueue] = useState<ActiveQueuePayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'waiting' | 'completed' | 'skipped' | 'audit'>('waiting');

  const [feedback, setFeedback] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  const [confirmAction, setConfirmAction] = useState<{
    title: string;
    description: string;
    confirmLabel: string;
    tone: 'teal' | 'amber' | 'rose';
    onConfirm: () => Promise<void>;
  } | null>(null);

  const [noteTarget, setNoteTarget] = useState<QueueAppointmentItem | null>(null);
  const [noteForm, setNoteForm] = useState({
    diagnosis: '',
    medications: '',
    instructions: '',
    followUp: '',
  });
  const [busy, setBusy] = useState(false);

  const loadConsole = useCallback(async () => {
    try {
      const qs = new URLSearchParams({ doctorId: activeDoctorId });
      if (selectedSessionId && selectedSessionId.includes(activeDoctorId)) {
        qs.set('sessionId', selectedSessionId);
      }
      const res = await fetch(`/api/doctor/sessions?${qs.toString()}`);
      const data = await res.json();
      setDoctors(data.doctors || []);
      setSessions(data.sessions || []);
      setActiveQueue(data.activeQueue || null);
      if (data.activeQueue?.session?.id && !selectedSessionId.includes(activeDoctorId)) {
        setSelectedSessionId(data.activeQueue.session.id);
      }
    } catch {
      setFeedback({ type: 'error', text: 'Unable to load doctor console data.' });
    } finally {
      setLoading(false);
    }
  }, [activeDoctorId, selectedSessionId]);

  useEffect(() => {
    setLoading(true);
    loadConsole();
    const unsub = subscribeUpdates(() => {
      loadConsole();
    });
    return unsub;
  }, [loadConsole, subscribeUpdates]);

  const executeApi = async (
    url: string,
    body: Record<string, unknown>,
    successMessage: string
  ) => {
    setBusy(true);
    setFeedback(null);
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) {
        setFeedback({ type: 'error', text: data.error || 'Action could not be completed.' });
        return;
      }
      setFeedback({ type: 'success', text: successMessage });
      triggerLocalRefresh();
    } catch {
      setFeedback({ type: 'error', text: 'Network error while updating queue.' });
    } finally {
      setBusy(false);
      setConfirmAction(null);
    }
  };

  const handleCallNextClick = () => {
    if (!activeQueue) return;
    const nextPat = activeQueue.waitingList[0];
    if (!nextPat) {
      setFeedback({ type: 'error', text: 'No waiting patients remaining in this session.' });
      return;
    }

    const current = activeQueue.activeAppointment;
    if (current) {
      setConfirmAction({
        title: `Complete Token #${current.token_number} & Call #${nextPat.token_number}`,
        description: `Token #${current.token_number} (${current.patientName}) is currently in consultation. Confirming will mark #${current.token_number} complete (logging duration to EWMA) and immediately call Token #${nextPat.token_number} (${nextPat.patientName}).`,
        confirmLabel: `Complete #${current.token_number} & Call #${nextPat.token_number}`,
        tone: 'teal',
        onConfirm: async () => {
          await executeApi(
            `/api/doctor/sessions/${activeQueue.session.id}/call-next`,
            { completeCurrent: true },
            `Completed Token #${current.token_number} and called Token #${nextPat.token_number}.`
          );
        },
      });
    } else {
      setConfirmAction({
        title: `Call Next Patient: Token #${nextPat.token_number}`,
        description: `Call ${nextPat.patientName} (Token #${nextPat.token_number}) into ${activeQueue.doctor.room_number} and recalculate all patient wait estimates.`,
        confirmLabel: `Call Token #${nextPat.token_number}`,
        tone: 'teal',
        onConfirm: async () => {
          await executeApi(
            `/api/doctor/sessions/${activeQueue.session.id}/call-next`,
            { completeCurrent: false },
            `Called Token #${nextPat.token_number} (${nextPat.patientName}).`
          );
        },
      });
    }
  };

  const handleCompleteCurrent = () => {
    if (!activeQueue?.activeAppointment) {
      setFeedback({
        type: 'error',
        text: 'Invalid action: No patient has been called into consultation yet.',
      });
      return;
    }
    const curr = activeQueue.activeAppointment;
    setConfirmAction({
      title: `Mark Token #${curr.token_number} Complete`,
      description: `Finish consultation for ${curr.patientName} and record its duration into your EWMA estimate.`,
      confirmLabel: 'Mark Complete',
      tone: 'teal',
      onConfirm: async () => {
        await executeApi(
          `/api/doctor/appointments/${curr.id}/complete`,
          {},
          `Marked Token #${curr.token_number} complete and updated EWMA pace.`
        );
      },
    });
  };

  const handleMarkAbsent = (appt: QueueAppointmentItem) => {
    setConfirmAction({
      title: `Mark Token #${appt.token_number} Absent / Skip`,
      description: `Move ${appt.patientName} (Token #${appt.token_number}) to the skipped list and advance the queue immediately without stalling remaining patients.`,
      confirmLabel: 'Mark Absent & Advance',
      tone: 'rose',
      onConfirm: async () => {
        await executeApi(
          `/api/doctor/appointments/${appt.id}/absent`,
          {},
          `Token #${appt.token_number} marked absent/skipped; queue advanced.`
        );
      },
    });
  };

  const handleDelay10 = () => {
    if (!activeQueue) return;
    setConfirmAction({
      title: 'Report +10 Minute Delay',
      description:
        'Add 10 minutes to the session delay and immediately update wait estimates for all waiting patients.',
      confirmLabel: 'Add +10 Min Delay',
      tone: 'amber',
      onConfirm: async () => {
        await executeApi(
          `/api/doctor/sessions/${activeQueue.session.id}/status`,
          { status: 'delayed', addDelayMinutes: 10 },
          'Added +10 minute delay and recalculated queue wait estimates.'
        );
      },
    });
  };

  const handleStatusToggle = (targetStatus: DoctorSessionStatus, resetDelay = false) => {
    if (!activeQueue) return;
    const label = targetStatus === 'on_break' ? 'On Break' : 'In Consultation';
    setConfirmAction({
      title: resetDelay ? 'Resume & Clear Delay' : `Switch Status to ${label}`,
      description: resetDelay
        ? 'Reset session delay to 0 minutes and set status to In Consultation.'
        : targetStatus === 'on_break'
        ? 'Pause queue progression and notify waiting patients with a break buffer.'
        : 'Resume active consultations for this session.',
      confirmLabel: `Set ${label}`,
      tone: targetStatus === 'on_break' ? 'amber' : 'teal',
      onConfirm: async () => {
        await executeApi(
          `/api/doctor/sessions/${activeQueue.session.id}/status`,
          { status: targetStatus, resetDelay },
          `Session status updated to ${label}.`
        );
      },
    });
  };

  const handleSaveNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteTarget) return;
    await executeApi(
      `/api/doctor/appointments/${noteTarget.id}/note`,
      noteForm,
      `Saved visit summary for Token #${noteTarget.token_number}.`
    );
    setNoteTarget(null);
  };

  const openNoteModal = (appt: QueueAppointmentItem) => {
    setNoteTarget(appt);
    setNoteForm({
      diagnosis: appt.visitNote?.diagnosis || '',
      medications: appt.visitNote?.medications || '',
      instructions: appt.visitNote?.instructions || '',
      followUp: appt.visitNote?.follow_up || '',
    });
  };

  const formatTime = (iso: string | null) => {
    if (!iso) return '—';
    try {
      return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch {
      return '—';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Top Workspace Control Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900">Doctor Session Console</h1>
          {activeQueue && (
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              {activeQueue.doctor.name} · {activeQueue.doctor.specialty} · {activeQueue.clinic.name} ·{' '}
              {activeQueue.doctor.room_number}
            </p>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div>
            <label htmlFor="console-doctor-select" className="sr-only">
              Select doctor
            </label>
            <select
              id="console-doctor-select"
              value={activeDoctorId}
              onChange={(e) => {
                setActiveDoctorId(e.target.value);
                setSelectedSessionId('');
              }}
              className="px-3 py-2 rounded-lg border border-slate-300 bg-white text-xs sm:text-sm font-medium text-slate-900 focus:border-teal-700 focus:outline-none"
            >
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} ({d.specialty} · {d.clinic_name})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="console-session-select" className="sr-only">
              Select clinic session
            </label>
            <select
              id="console-session-select"
              value={activeQueue?.session.id || selectedSessionId}
              onChange={(e) => setSelectedSessionId(e.target.value)}
              className="px-3 py-2 rounded-lg border border-slate-300 bg-white text-xs sm:text-sm font-medium text-slate-900 focus:border-teal-700 focus:outline-none"
            >
              {sessions.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.session_date} · {s.period === 'morning' ? 'Morning' : 'Evening'} ({s.start_time}–
                  {s.end_time})
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {feedback && (
        <div
          role="status"
          className={`p-4 rounded-xl border text-sm flex items-center justify-between gap-4 ${
            feedback.type === 'error'
              ? 'bg-rose-50 border-rose-200 text-rose-900'
              : 'bg-emerald-50 border-emerald-200 text-emerald-900'
          }`}
        >
          <span>{feedback.text}</span>
          <button
            type="button"
            onClick={() => setFeedback(null)}
            aria-label="Dismiss notification"
            className="p-1 rounded hover:bg-black/5 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {loading || !activeQueue ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 h-64 animate-pulse" />
      ) : (
        <>
          {/* KPI & Status Strip */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs text-slate-500">Session Status</div>
              <div className="mt-2">
                <DoctorStatusIndicator
                  status={activeQueue.session.status}
                  delayMinutes={activeQueue.session.delay_minutes}
                />
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs text-slate-500">Current Token Served</div>
              <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 mt-1">
                {activeQueue.currentTokenNumber ? `#${activeQueue.currentTokenNumber}` : 'None'}
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs text-slate-500">Waiting in Queue</div>
              <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 mt-1">
                {activeQueue.waitingList.length} patients
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs text-slate-500">EWMA Consultation Pace</div>
              <div className="text-2xl font-bold font-mono tabular-nums text-teal-800 mt-1">
                {activeQueue.ewmaMinutes} min/pt
              </div>
            </div>
          </div>

          {/* Main 2-Column Split: Active Consultation + Session Controls */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
            {/* Active Patient Panel */}
            <section
              aria-labelledby="current-patient-heading"
              className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between gap-6"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between gap-4">
                  <h2 id="current-patient-heading" className="text-lg font-semibold text-slate-900">
                    Current Patient in Consultation
                  </h2>
                  {activeQueue.activeAppointment && (
                    <AppointmentStatusIndicator
                      status={activeQueue.activeAppointment.status}
                      isUrgent={activeQueue.activeAppointment.is_urgent === 1}
                    />
                  )}
                </div>

                {activeQueue.activeAppointment ? (
                  <div className="p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                    <div className="flex flex-wrap items-baseline justify-between gap-2">
                      <div className="flex items-baseline gap-3">
                        <span className="text-3xl font-bold font-mono tabular-nums text-teal-800">
                          #{activeQueue.activeAppointment.token_number}
                        </span>
                        <span className="text-lg font-semibold text-slate-900">
                          {activeQueue.activeAppointment.patientName}
                        </span>
                      </div>
                      <span className="text-xs text-slate-500 font-mono tabular-nums">
                        Started: {formatTime(activeQueue.activeAppointment.started_at)}
                      </span>
                    </div>

                    <p className="text-sm text-slate-700">
                      <span className="font-medium text-slate-900">Reason:</span>{' '}
                      {activeQueue.activeAppointment.reason || 'General outpatient consultation'}
                    </p>
                    <p className="text-xs text-slate-500 font-mono">
                      Contact: {activeQueue.activeAppointment.patientPhoneMasked} · Check-in:{' '}
                      {activeQueue.activeAppointment.checkin_method || 'Walk-in / Pending'}
                    </p>
                  </div>
                ) : (
                  <div className="p-6 rounded-xl bg-slate-50 border border-slate-200 text-center space-y-2">
                    <p className="text-sm font-semibold text-slate-900">
                      No patient currently in consultation
                    </p>
                    <p className="text-xs text-slate-600">
                      Click “Call Next Patient” to bring in the next person from the waiting queue.
                    </p>
                  </div>
                )}
              </div>

              {/* Primary Queue Action Buttons */}
              <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  disabled={busy || activeQueue.waitingList.length === 0}
                  onClick={handleCallNextClick}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-teal-700 text-white text-sm font-semibold hover:bg-teal-800 disabled:opacity-50 transition-colors cursor-pointer"
                >
                  <Play className="w-4 h-4" aria-hidden="true" />
                  <span>Call Next Patient</span>
                </button>

                <button
                  type="button"
                  disabled={busy || !activeQueue.activeAppointment}
                  onClick={handleCompleteCurrent}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-slate-300 bg-white text-slate-800 text-sm font-semibold hover:bg-slate-50 disabled:opacity-45 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-700" aria-hidden="true" />
                  <span>Mark Consultation Complete</span>
                </button>

                {activeQueue.activeAppointment && (
                  <>
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => handleMarkAbsent(activeQueue.activeAppointment!)}
                      className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-rose-200 bg-rose-50 text-rose-800 text-sm font-semibold hover:bg-rose-100 cursor-pointer"
                    >
                      <UserX className="w-4 h-4" aria-hidden="true" />
                      <span>Mark Patient Absent / Skip</span>
                    </button>

                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => openNoteModal(activeQueue.activeAppointment!)}
                      className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-slate-300 text-slate-700 text-sm font-medium hover:bg-slate-50 cursor-pointer"
                    >
                      <FileText className="w-4 h-4 text-teal-700" aria-hidden="true" />
                      <span>Attach Rx / Summary</span>
                    </button>
                  </>
                )}
              </div>
            </section>

            {/* Doctor Status & Delay Controls */}
            <section
              aria-labelledby="session-controls-heading"
              className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between gap-5"
            >
              <div className="space-y-4">
                <h2 id="session-controls-heading" className="text-lg font-semibold text-slate-900">
                  Doctor Availability & Delays
                </h2>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Updating your status or reporting a delay immediately recalculates all waiting patients’ estimates and updates their live queue screen.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    disabled={busy}
                    onClick={handleDelay10}
                    className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border border-amber-300 bg-amber-50 text-amber-900 text-sm font-semibold hover:bg-amber-100 cursor-pointer"
                  >
                    <Clock className="w-4 h-4" aria-hidden="true" />
                    <span>Delay 10 Minutes</span>
                  </button>

                  {activeQueue.session.status === 'on_break' ? (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => handleStatusToggle('in_consultation')}
                      className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-slate-900 text-white text-sm font-semibold hover:bg-slate-800 cursor-pointer"
                    >
                      <Stethoscope className="w-4 h-4" aria-hidden="true" />
                      <span>Resume Consultation</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => handleStatusToggle('on_break')}
                      className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border border-slate-300 bg-white text-slate-800 text-sm font-semibold hover:bg-slate-50 cursor-pointer"
                    >
                      <Coffee className="w-4 h-4 text-amber-700" aria-hidden="true" />
                      <span>Set On Break</span>
                    </button>
                  )}
                </div>

                {activeQueue.session.delay_minutes > 0 && (
                  <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-between gap-3 text-xs text-amber-900">
                    <span className="flex items-center gap-1.5 font-medium tabular-nums">
                      <AlertTriangle className="w-4 h-4 shrink-0" aria-hidden="true" />
                      <span>Active delay: +{activeQueue.session.delay_minutes} min</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => handleStatusToggle('in_consultation', true)}
                      className="font-semibold underline hover:no-underline cursor-pointer"
                    >
                      Clear Delay
                    </button>
                  </div>
                )}
              </div>

              <div className="pt-4 border-t border-slate-200 text-xs text-slate-600">
                <div className="font-semibold text-slate-800 mb-1.5">
                  Recent Completed Durations (EWMA Inputs)
                </div>
                <div className="flex flex-wrap gap-2 font-mono tabular-nums">
                  {activeQueue.recentDurations.length === 0 ? (
                    <span>Baseline: {activeQueue.doctor.historical_avg_minutes}m avg</span>
                  ) : (
                    activeQueue.recentDurations.map((d, i) => (
                      <span key={i} className="px-2 py-1 rounded bg-slate-100 text-slate-700">
                        {d.duration_minutes}m
                      </span>
                    ))
                  )}
                </div>
              </div>
            </section>
          </div>

          {/* Queue & Audit Tabs */}
          <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4">
              <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg">
                <button
                  type="button"
                  onClick={() => setTab('waiting')}
                  className={`px-3.5 py-1.5 rounded-md text-xs font-medium cursor-pointer ${
                    tab === 'waiting'
                      ? 'bg-white text-slate-900 shadow-sm font-semibold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Next in Queue ({activeQueue.waitingList.length})
                </button>
                <button
                  type="button"
                  onClick={() => setTab('completed')}
                  className={`px-3.5 py-1.5 rounded-md text-xs font-medium cursor-pointer ${
                    tab === 'completed'
                      ? 'bg-white text-slate-900 shadow-sm font-semibold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Completed ({activeQueue.completedList.length})
                </button>
                <button
                  type="button"
                  onClick={() => setTab('skipped')}
                  className={`px-3.5 py-1.5 rounded-md text-xs font-medium cursor-pointer ${
                    tab === 'skipped'
                      ? 'bg-white text-slate-900 shadow-sm font-semibold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Absent / Skipped ({activeQueue.skippedList.length})
                </button>
                <button
                  type="button"
                  onClick={() => setTab('audit')}
                  className={`px-3.5 py-1.5 rounded-md text-xs font-medium cursor-pointer ${
                    tab === 'audit'
                      ? 'bg-white text-slate-900 shadow-sm font-semibold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Session Audit Log
                </button>
              </div>
            </div>

            {tab === 'waiting' && (
              <div className="overflow-x-auto">
                {activeQueue.waitingList.length === 0 ? (
                  <div className="p-10 text-center text-sm text-slate-600">
                    No patients currently waiting in this session.
                  </div>
                ) : (
                  <table className="w-full text-left border-collapse text-sm">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50 text-xs text-slate-500">
                        <th className="py-3 px-5 font-medium">Token</th>
                        <th className="py-3 px-4 font-medium">Patient</th>
                        <th className="py-3 px-4 font-medium">Reason</th>
                        <th className="py-3 px-4 font-medium">Status</th>
                        <th className="py-3 px-4 font-medium text-right">Est. Wait</th>
                        <th className="py-3 px-5 font-medium text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {activeQueue.waitingList.map((item, idx) => (
                        <tr key={item.id} className="hover:bg-slate-50/70">
                          <td className="py-3 px-5 font-mono tabular-nums font-semibold text-slate-900">
                            #{item.token_number}
                            {idx === 0 && (
                              <span className="ml-2 text-xs font-sans font-medium text-teal-800">
                                · Next
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            <div className="font-medium text-slate-900">{item.patientName}</div>
                            <div className="text-xs text-slate-500 font-mono">
                              {item.patientPhoneMasked}
                            </div>
                          </td>
                          <td className="py-3 px-4 text-slate-600 max-w-xs truncate">
                            {item.reason || 'Outpatient consultation'}
                          </td>
                          <td className="py-3 px-4">
                            <AppointmentStatusIndicator
                              status={item.status}
                              isUrgent={item.is_urgent === 1}
                            />
                          </td>
                          <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-800">
                            ~{item.estimatedWaitMinutes ?? 0}m
                          </td>
                          <td className="py-3 px-5 text-right">
                            <button
                              type="button"
                              disabled={busy}
                              onClick={() => handleMarkAbsent(item)}
                              className="px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-medium text-slate-700 hover:bg-slate-100 cursor-pointer"
                            >
                              Skip / Absent
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            )}

            {tab === 'completed' && (
              <div className="overflow-x-auto">
                {activeQueue.completedList.length === 0 ? (
                  <div className="p-10 text-center text-sm text-slate-600">
                    No completed consultations in this session yet.
                  </div>
                ) : (
                  <table className="w-full text-left border-collapse text-sm">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50 text-xs text-slate-500">
                        <th className="py-3 px-5 font-medium">Token</th>
                        <th className="py-3 px-4 font-medium">Patient</th>
                        <th className="py-3 px-4 font-medium">Completed At</th>
                        <th className="py-3 px-5 font-medium text-right">Visit Summary / Rx</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {activeQueue.completedList.map((item) => (
                        <tr key={item.id}>
                          <td className="py-3 px-5 font-mono tabular-nums font-semibold text-slate-900">
                            #{item.token_number}
                          </td>
                          <td className="py-3 px-4 font-medium text-slate-900">
                            {item.patientName}
                          </td>
                          <td className="py-3 px-4 font-mono tabular-nums text-xs text-slate-600">
                            {formatTime(item.completed_at)}
                          </td>
                          <td className="py-3 px-5 text-right">
                            <button
                              type="button"
                              onClick={() => openNoteModal(item)}
                              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-medium text-slate-800 hover:bg-slate-50 cursor-pointer"
                            >
                              <FileText className="w-3.5 h-3.5 text-teal-700" aria-hidden="true" />
                              <span>{item.visitNote ? 'Edit Summary / Rx' : 'Attach Summary / Rx'}</span>
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            )}

            {tab === 'skipped' && (
              <div className="overflow-x-auto">
                {activeQueue.skippedList.length === 0 ? (
                  <div className="p-10 text-center text-sm text-slate-600">
                    No skipped or absent patients in this session.
                  </div>
                ) : (
                  <table className="w-full text-left border-collapse text-sm">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50 text-xs text-slate-500">
                        <th className="py-3 px-5 font-medium">Token</th>
                        <th className="py-3 px-4 font-medium">Patient</th>
                        <th className="py-3 px-4 font-medium">Status</th>
                        <th className="py-3 px-5 font-medium text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {activeQueue.skippedList.map((item) => (
                        <tr key={item.id}>
                          <td className="py-3 px-5 font-mono tabular-nums font-semibold text-slate-900">
                            #{item.token_number}
                          </td>
                          <td className="py-3 px-4 font-medium text-slate-900">
                            {item.patientName}
                          </td>
                          <td className="py-3 px-4">
                            <AppointmentStatusIndicator status={item.status} />
                          </td>
                          <td className="py-3 px-5 text-right">
                            <button
                              type="button"
                              disabled={busy}
                              onClick={() =>
                                executeApi(
                                  `/api/doctor/appointments/${item.id}/recall`,
                                  {},
                                  `Recalled Token #${item.token_number} back into active waiting queue.`
                                )
                              }
                              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-teal-700 text-xs font-semibold text-teal-800 hover:bg-teal-50 cursor-pointer"
                            >
                              <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                              <span>Recall to Queue</span>
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            )}

            {tab === 'audit' && (
              <div className="divide-y divide-slate-200">
                {activeQueue.auditLogs.map((log) => (
                  <div
                    key={log.id}
                    className="px-6 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                  >
                    <div>
                      <span className="font-semibold text-slate-900">{log.actor_name}</span>
                      <span className="text-slate-400 mx-1.5">·</span>
                      <span className="text-slate-700">{log.details}</span>
                    </div>
                    <span className="font-mono tabular-nums text-slate-500 shrink-0">
                      {formatTime(log.created_at)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </section>
        </>
      )}

      {/* Confirmation Dialog for Queue-Changing Actions */}
      {confirmAction && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="confirm-action-title"
        >
          <div className="bg-white border border-slate-200 rounded-xl max-w-md w-full p-6 space-y-4 shadow-xl">
            <h3 id="confirm-action-title" className="text-base font-semibold text-slate-900">
              {confirmAction.title}
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">{confirmAction.description}</p>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                disabled={busy}
                onClick={() => setConfirmAction(null)}
                className="px-4 py-2 rounded-lg border border-slate-300 text-sm font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={busy}
                onClick={confirmAction.onConfirm}
                className={`px-4 py-2 rounded-lg text-white text-sm font-semibold disabled:opacity-60 cursor-pointer ${
                  confirmAction.tone === 'rose'
                    ? 'bg-rose-700 hover:bg-rose-800'
                    : confirmAction.tone === 'amber'
                    ? 'bg-amber-700 hover:bg-amber-800'
                    : 'bg-teal-700 hover:bg-teal-800'
                }`}
              >
                {busy ? 'Updating...' : confirmAction.confirmLabel}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Visit Summary / Prescription Attachment Modal */}
      {noteTarget && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="attach-note-title"
        >
          <form
            onSubmit={handleSaveNote}
            className="bg-white border border-slate-200 rounded-xl max-w-lg w-full p-6 space-y-4 shadow-xl"
          >
            <div className="flex items-start justify-between gap-4 pb-3 border-b border-slate-200">
              <div>
                <h3 id="attach-note-title" className="text-base font-semibold text-slate-900">
                  Visit Summary & Prescription · Token #{noteTarget.token_number}
                </h3>
                <p className="text-xs text-slate-600 mt-0.5">
                  Patient: {noteTarget.patientName} · Restricted to patient & care team
                </p>
              </div>
              <button
                type="button"
                onClick={() => setNoteTarget(null)}
                aria-label="Close prescription form"
                className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label htmlFor="rx-diagnosis" className="block text-xs font-semibold text-slate-700 mb-1">
                  Clinical Summary / Assessment
                </label>
                <input
                  id="rx-diagnosis"
                  type="text"
                  required
                  value={noteForm.diagnosis}
                  onChange={(e) => setNoteForm((p) => ({ ...p, diagnosis: e.target.value }))}
                  placeholder="e.g. Controlled essential hypertension"
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:border-teal-700 focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="rx-meds" className="block text-xs font-semibold text-slate-700 mb-1">
                  Medications
                </label>
                <textarea
                  id="rx-meds"
                  rows={2}
                  value={noteForm.medications}
                  onChange={(e) => setNoteForm((p) => ({ ...p, medications: e.target.value }))}
                  placeholder="e.g. Amlodipine 5 mg once daily after breakfast"
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:border-teal-700 focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="rx-instructions" className="block text-xs font-semibold text-slate-700 mb-1">
                  Care Instructions
                </label>
                <textarea
                  id="rx-instructions"
                  rows={2}
                  value={noteForm.instructions}
                  onChange={(e) => setNoteForm((p) => ({ ...p, instructions: e.target.value }))}
                  placeholder="e.g. Home blood pressure log twice weekly; reduce dietary sodium."
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:border-teal-700 focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="rx-followup" className="block text-xs font-semibold text-slate-700 mb-1">
                  Follow-up Plan (optional)
                </label>
                <input
                  id="rx-followup"
                  type="text"
                  value={noteForm.followUp}
                  onChange={(e) => setNoteForm((p) => ({ ...p, followUp: e.target.value }))}
                  placeholder="e.g. Follow up in 4 weeks"
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:border-teal-700 focus:outline-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setNoteTarget(null)}
                className="px-4 py-2 rounded-lg border border-slate-300 text-sm font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={busy}
                className="px-4 py-2 rounded-lg bg-teal-700 text-white text-sm font-semibold hover:bg-teal-800 cursor-pointer"
              >
                {busy ? 'Saving...' : 'Save Visit Summary'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
