import {
  AlertCircle,
  Bell,
  CheckCircle2,
  Clock,
  FileText,
  MapPin,
  Navigation,
  RefreshCw,
  ShieldCheck,
  X,
} from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  AppointmentStatusIndicator,
  DoctorStatusIndicator,
} from '../components/StatusBadge';
import { useAppContext } from '../context/AppContext';
import type { DemoPatient, NotificationItem, PatientAppointment, VisitNote } from '../types';

export function MyAppointmentsPage() {
  const {
    activePatientId,
    setActivePatientId,
    wsConnected,
    lastSyncAt,
    subscribeUpdates,
    triggerLocalRefresh,
  } = useAppContext();

  const [demoPatients, setDemoPatients] = useState<DemoPatient[]>([]);
  const [patientInfo, setPatientInfo] = useState<{
    id: string;
    full_name: string;
    phone: string;
  } | null>(null);
  const [appointments, setAppointments] = useState<PatientAppointment[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionBanner, setActionBanner] = useState<{
    type: 'success' | 'error' | 'info';
    text: string;
  } | null>(null);

  const [geoConsentAppt, setGeoConsentAppt] = useState<PatientAppointment | null>(null);
  const [geoChecking, setGeoChecking] = useState(false);
  const [selectedNote, setSelectedNote] = useState<{
    appt: PatientAppointment;
    note: VisitNote;
  } | null>(null);

  const loadData = useCallback(async () => {
    try {
      const [patRes, myRes] = await Promise.all([
        fetch('/api/patients/demo'),
        fetch(`/api/appointments/my?patientId=${encodeURIComponent(activePatientId)}`),
      ]);
      const patJson = await patRes.json();
      const myJson = await myRes.json();
      if (Array.isArray(patJson.patients)) setDemoPatients(patJson.patients);
      setPatientInfo(myJson.patient || null);
      setAppointments(myJson.appointments || []);
      setNotifications(myJson.notifications || []);
    } catch {
      setActionBanner({
        type: 'error',
        text: 'Unable to refresh queue status. Retrying automatically.',
      });
    } finally {
      setLoading(false);
    }
  }, [activePatientId]);

  useEffect(() => {
    setLoading(true);
    loadData();
    const unsub = subscribeUpdates(() => {
      loadData();
    });
    return unsub;
  }, [loadData, subscribeUpdates]);

  const activeAppointments = appointments.filter((a) =>
    ['waiting', 'checked_in', 'called', 'in_consultation'].includes(a.status)
  );
  const pastAppointments = appointments.filter((a) =>
    ['completed', 'skipped', 'cancelled'].includes(a.status)
  );
  const unreadCount = notifications.filter((n) => n.is_read === 0).length;

  const handleManualCheckIn = async (apptId: string) => {
    setActionBanner(null);
    try {
      const res = await fetch(`/api/appointments/${apptId}/checkin`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode: 'manual', patientId: activePatientId }),
      });
      const data = await res.json();
      if (!res.ok) {
        setActionBanner({ type: 'error', text: data.error || 'Check-in failed.' });
        return;
      }
      setActionBanner({
        type: 'success',
        text: 'Checked in manually. Please stay near the waiting area until your token is called.',
      });
      triggerLocalRefresh();
    } catch {
      setActionBanner({ type: 'error', text: 'Network error during check-in.' });
    }
  };

  const handleGeoCheckIn = (appt: PatientAppointment) => {
    if (!navigator.geolocation) {
      setActionBanner({
        type: 'error',
        text: 'Geolocation is not supported in this browser. Please use Manual Check-In instead.',
      });
      setGeoConsentAppt(null);
      return;
    }

    setGeoChecking(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const res = await fetch(`/api/appointments/${appt.id}/checkin`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              mode: 'geolocation',
              patientId: activePatientId,
              latitude: pos.coords.latitude,
              longitude: pos.coords.longitude,
            }),
          });
          const data = await res.json();
          if (!res.ok) {
            setActionBanner({
              type: 'error',
              text: data.error || 'Proximity check-in failed. Use Manual Check-In if you are at the desk.',
            });
          } else {
            setActionBanner({
              type: 'success',
              text: `Location verified (${data.distanceMeters}m from clinic). You are checked in!`,
            });
            triggerLocalRefresh();
          }
        } catch {
          setActionBanner({ type: 'error', text: 'Network error verifying location.' });
        } finally {
          setGeoChecking(false);
          setGeoConsentAppt(null);
        }
      },
      () => {
        setGeoChecking(false);
        setGeoConsentAppt(null);
        setActionBanner({
          type: 'info',
          text: 'Location permission was declined or unavailable. You can use Manual Check-In anytime.',
        });
      },
      { enableHighAccuracy: false, timeout: 8000, maximumAge: 0 }
    );
  };

  const handleCancel = async (appt: PatientAppointment) => {
    if (!window.confirm(`Cancel Token #${appt.token_number} with ${appt.doctor?.name}?`)) {
      return;
    }
    try {
      const res = await fetch(`/api/appointments/${appt.id}/cancel`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ patientId: activePatientId }),
      });
      const data = await res.json();
      if (!res.ok) {
        setActionBanner({ type: 'error', text: data.error || 'Cancellation failed.' });
        return;
      }
      setActionBanner({ type: 'info', text: `Token #${appt.token_number} cancelled.` });
      triggerLocalRefresh();
    } catch {
      setActionBanner({ type: 'error', text: 'Network error cancelling appointment.' });
    }
  };

  const handleMarkNotificationsRead = async () => {
    await fetch('/api/notifications/read', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ patientId: activePatientId }),
    });
    loadData();
  };

  const formatTime = (iso: string) => {
    try {
      return new Date(iso).toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
    } catch {
      return '';
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Page Header & Privacy-Scoped Account Switcher */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">My Appointments & Live Queue</h1>
          <p className="text-sm text-slate-600 mt-1 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-teal-700 shrink-0" aria-hidden="true" />
            <span>
              Viewing private queue details for{' '}
              <strong className="text-slate-900">
                {patientInfo?.full_name || 'Selected Patient'}
              </strong>
              . Other patients’ details are never exposed.
            </span>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <label htmlFor="patient-profile-select" className="text-xs font-medium text-slate-600">
              Patient profile:
            </label>
            <select
              id="patient-profile-select"
              value={activePatientId}
              onChange={(e) => setActivePatientId(e.target.value)}
              className="px-3 py-2 rounded-lg border border-slate-300 bg-white text-xs font-medium text-slate-900 focus:border-teal-700 focus:outline-none"
            >
              {demoPatients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.full_name} ({p.maskedPhone})
                </option>
              ))}
            </select>
          </div>

          <button
            type="button"
            onClick={loadData}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-300 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
            <span className="tabular-nums">
              {wsConnected ? 'Live Sync' : '3s Auto-Refresh'} · {formatTime(lastSyncAt)}
            </span>
          </button>
        </div>
      </div>

      {actionBanner && (
        <div
          role="status"
          className={`p-4 rounded-xl border text-sm flex items-center justify-between gap-4 ${
            actionBanner.type === 'error'
              ? 'bg-rose-50 border-rose-200 text-rose-900'
              : actionBanner.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : 'bg-amber-50 border-amber-200 text-amber-900'
          }`}
        >
          <span>{actionBanner.text}</span>
          <button
            type="button"
            onClick={() => setActionBanner(null)}
            aria-label="Dismiss message"
            className="p-1 rounded hover:bg-black/5 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Simulated In-App Notification Panel */}
      <section
        aria-labelledby="alerts-heading"
        className="bg-white border border-slate-200 rounded-xl p-6"
      >
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-teal-700" aria-hidden="true" />
            <h2 id="alerts-heading" className="text-base font-semibold text-slate-900">
              Simulated Queue Alerts ({unreadCount} unread)
            </h2>
          </div>
          <div className="flex items-center gap-4 text-xs text-slate-500">
            <span>Simulated in-app alerts · No external SMS is sent</span>
            {unreadCount > 0 && (
              <button
                type="button"
                onClick={handleMarkNotificationsRead}
                className="text-teal-800 font-medium hover:underline cursor-pointer"
              >
                Mark all read
              </button>
            )}
          </div>
        </div>

        {notifications.length === 0 ? (
          <p className="text-sm text-slate-600">
            No queue alerts yet. When your booked token is 2 positions away or called, an alert will appear here automatically.
          </p>
        ) : (
          <ul className="divide-y divide-slate-200">
            {notifications.slice(0, 5).map((notif) => (
              <li
                key={notif.id}
                className={`py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 ${
                  notif.is_read === 0 ? 'bg-amber-50/40 -mx-3 px-3 rounded-lg' : ''
                }`}
              >
                <div className="space-y-0.5">
                  <div className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                    <span>{notif.title}</span>
                    {notif.is_read === 0 && (
                      <span className="text-xs font-medium text-amber-800">· New</span>
                    )}
                  </div>
                  <p className="text-sm text-slate-700">{notif.message}</p>
                </div>
                <div className="text-xs text-slate-500 font-mono tabular-nums whitespace-nowrap shrink-0">
                  {notif.channel} · {formatTime(notif.created_at)}
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* Active Queue Tracking Section */}
      <section aria-labelledby="active-queue-heading" className="space-y-4">
        <h2 id="active-queue-heading" className="text-xl font-semibold text-slate-900">
          Active Queue Tracking
        </h2>

        {loading ? (
          <div className="bg-white border border-slate-200 rounded-xl p-8 h-52 animate-pulse" />
        ) : activeAppointments.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-10 text-center space-y-3">
            <p className="text-base font-semibold text-slate-900">
              No active queue tokens for {patientInfo?.full_name || 'this account'}
            </p>
            <p className="text-sm text-slate-600">
              Book an outpatient clinic session to receive a sequential queue token and live wait estimate.
            </p>
            <Link
              to="/"
              className="inline-flex items-center px-5 py-2.5 rounded-lg bg-teal-700 text-white text-sm font-semibold hover:bg-teal-800"
            >
              Find a Doctor & Book Token
            </Link>
          </div>
        ) : (
          <div className="space-y-5">
            {activeAppointments.map((appt) => {
              const isTwoOrLess =
                appt.status === 'waiting' || appt.status === 'checked_in'
                  ? appt.patientsAhead > 0 && appt.patientsAhead <= 2
                  : false;
              const isTurnNow = appt.status === 'called' || appt.status === 'in_consultation';

              return (
                <article
                  key={appt.id}
                  className="bg-white border border-slate-200 rounded-xl p-6 space-y-6"
                >
                  {/* Top Summary */}
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-5 border-b border-slate-200">
                    <div>
                      <div className="flex flex-wrap items-center gap-2.5">
                        <h3 className="text-lg font-semibold text-slate-900">
                          {appt.doctor?.name}
                        </h3>
                        {appt.session && (
                          <DoctorStatusIndicator
                            status={appt.session.status}
                            delayMinutes={appt.session.delay_minutes}
                          />
                        )}
                      </div>
                      <p className="text-xs text-slate-600 mt-1">
                        {appt.doctor?.specialty} · {appt.clinic?.name} · {appt.doctor?.room_number} ·{' '}
                        {appt.session?.session_date} ({appt.session?.period} {appt.session?.start_time}–
                        {appt.session?.end_time})
                      </p>
                    </div>

                    <AppointmentStatusIndicator
                      status={appt.status}
                      isUrgent={appt.is_urgent === 1}
                    />
                  </div>

                  {/* Two-Position-Away Callout Banner */}
                  {isTwoOrLess && (
                    <div
                      role="alert"
                      className="p-4 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 flex items-start gap-3"
                    >
                      <AlertCircle className="w-5 h-5 text-amber-700 mt-0.5 shrink-0" aria-hidden="true" />
                      <div className="text-sm">
                        <span className="font-semibold">
                          Heads up — you are {appt.patientsAhead}{' '}
                          {appt.patientsAhead === 1 ? 'position' : 'positions'} away.
                        </span>{' '}
                        Please head toward {appt.clinic?.name} ({appt.doctor?.room_number}) and check in when you arrive.
                      </div>
                    </div>
                  )}

                  {isTurnNow && (
                    <div
                      role="alert"
                      className="p-4 rounded-lg bg-teal-50 border border-teal-200 text-teal-900 flex items-start gap-3"
                    >
                      <CheckCircle2 className="w-5 h-5 text-teal-700 mt-0.5 shrink-0" aria-hidden="true" />
                      <div className="text-sm">
                        <span className="font-semibold">
                          It is your turn now (Token #{appt.token_number}).
                        </span>{' '}
                        Please proceed to {appt.doctor?.room_number}.
                      </div>
                    </div>
                  )}

                  {/* Primary Live Metrics */}
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
                      <div className="text-xs text-slate-500">Your Token Number</div>
                      <div className="text-3xl font-bold font-mono tabular-nums text-slate-900 mt-1">
                        #{appt.token_number}
                      </div>
                      <div className="text-xs text-slate-600 mt-1 tabular-nums">
                        {isTurnNow
                          ? 'Active now'
                          : `Queue position: #${appt.queuePosition ?? '-'}`}
                      </div>
                    </div>

                    <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
                      <div className="text-xs text-slate-500">Patients Ahead</div>
                      <div className="text-3xl font-bold font-mono tabular-nums text-slate-900 mt-1">
                        {appt.patientsAhead}
                      </div>
                      <div className="text-xs text-slate-600 mt-1 tabular-nums">
                        Current token served:{' '}
                        <strong>
                          {appt.currentTokenNumber ? `#${appt.currentTokenNumber}` : 'Starting soon'}
                        </strong>
                      </div>
                    </div>

                    <div className="p-4 rounded-lg bg-teal-50/70 border border-teal-200 col-span-2">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-medium text-teal-900 flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5" aria-hidden="true" />
                          <span>Estimated Wait (Estimate Only)</span>
                        </span>
                        <span className="text-xs text-slate-600 font-mono tabular-nums">
                          Updated {formatTime(appt.lastUpdated)}
                        </span>
                      </div>
                      <div className="text-3xl font-bold font-mono tabular-nums text-teal-900 mt-1">
                        {isTurnNow
                          ? '0 min'
                          : `~${appt.estimatedWaitMinutes ?? 0} min`}
                      </div>
                      <div className="text-xs text-slate-600 mt-1 leading-relaxed">
                        Calculated from {appt.patientsAhead} ahead × ~{appt.ewmaMinutes ?? 12} min EWMA pace
                        {appt.session && appt.session.delay_minutes > 0
                          ? ` + ${appt.session.delay_minutes} min delay`
                          : ''}
                        {appt.session?.status === 'on_break' ? ' + 10 min break buffer' : ''}.{' '}
                        <strong className="text-slate-800">
                          Estimate can change as consultations progress.
                        </strong>
                      </div>
                    </div>
                  </div>

                  {/* Check-in & Actions */}
                  <div className="pt-2 flex flex-wrap items-center justify-between gap-3">
                    <div className="text-xs text-slate-600 flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" aria-hidden="true" />
                      <span>
                        {appt.checked_in_at
                          ? `Checked in via ${appt.checkin_method} at ${formatTime(appt.checked_in_at)}`
                          : 'Not checked in yet · Check in upon arrival at clinic'}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-2.5">
                      {(appt.status === 'waiting') && (
                        <>
                          <button
                            type="button"
                            onClick={() => setGeoConsentAppt(appt)}
                            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-teal-700 text-teal-800 text-xs font-semibold hover:bg-teal-50 cursor-pointer"
                          >
                            <Navigation className="w-3.5 h-3.5" aria-hidden="true" />
                            <span>Check In with Location (500m)</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleManualCheckIn(appt.id)}
                            className="px-3.5 py-2 rounded-lg bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 cursor-pointer"
                          >
                            Manual Check-In
                          </button>
                        </>
                      )}
                      {(appt.status === 'waiting' || appt.status === 'checked_in') && (
                        <button
                          type="button"
                          onClick={() => handleCancel(appt)}
                          className="px-3.5 py-2 rounded-lg border border-slate-300 text-slate-700 text-xs font-medium hover:bg-slate-50 cursor-pointer"
                        >
                          Cancel Token
                        </button>
                      )}
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      {/* Past / Completed Appointments & Prescriptions */}
      {pastAppointments.length > 0 && (
        <section aria-labelledby="history-heading" className="space-y-4">
          <h2 id="history-heading" className="text-lg font-semibold text-slate-900">
            Completed & Past Appointments
          </h2>
          <div className="bg-white border border-slate-200 rounded-xl divide-y divide-slate-200">
            {pastAppointments.map((appt) => (
              <div
                key={appt.id}
                className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2.5">
                    <span className="font-mono tabular-nums text-sm font-semibold text-slate-900">
                      Token #{appt.token_number}
                    </span>
                    <span className="text-sm font-semibold text-slate-900">
                      {appt.doctor?.name}
                    </span>
                    <AppointmentStatusIndicator status={appt.status} />
                  </div>
                  <p className="text-xs text-slate-600">
                    {appt.doctor?.specialty} · {appt.clinic?.name} · {appt.session?.session_date} (
                    {appt.session?.period})
                  </p>
                </div>

                {appt.visitNote && (
                  <button
                    type="button"
                    onClick={() => setSelectedNote({ appt, note: appt.visitNote! })}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-800 hover:bg-slate-50 self-start sm:self-auto cursor-pointer"
                  >
                    <FileText className="w-3.5 h-3.5 text-teal-700" aria-hidden="true" />
                    <span>View Visit Summary & Rx</span>
                  </button>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Explicit Geolocation Permission Consent Dialog */}
      {geoConsentAppt && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="geo-consent-title"
        >
          <div className="bg-white border border-slate-200 rounded-xl max-w-md w-full p-6 space-y-4 shadow-xl">
            <h3 id="geo-consent-title" className="text-base font-semibold text-slate-900">
              One-Time Proximity Check-In
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              We request a single location reading solely to verify you are within 500 meters of{' '}
              <strong>{geoConsentAppt.clinic?.name}</strong> for check-in. Location is never tracked continuously or stored.
            </p>
            <div className="flex flex-col sm:flex-row justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => {
                  const id = geoConsentAppt.id;
                  setGeoConsentAppt(null);
                  handleManualCheckIn(id);
                }}
                className="px-4 py-2 rounded-lg border border-slate-300 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Use Manual Check-In Instead
              </button>
              <button
                type="button"
                disabled={geoChecking}
                onClick={() => handleGeoCheckIn(geoConsentAppt)}
                className="px-4 py-2 rounded-lg bg-teal-700 text-white text-xs font-semibold hover:bg-teal-800 disabled:opacity-60 cursor-pointer"
              >
                {geoChecking ? 'Checking Location...' : 'Allow One-Time Check'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Restricted Visit Summary / Prescription Modal */}
      {selectedNote && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="rx-modal-title"
        >
          <div className="bg-white border border-slate-200 rounded-xl max-w-lg w-full p-6 space-y-4 shadow-xl">
            <div className="flex items-start justify-between gap-4 pb-3 border-b border-slate-200">
              <div>
                <h3 id="rx-modal-title" className="text-base font-semibold text-slate-900">
                  Visit Summary & Prescription
                </h3>
                <p className="text-xs text-slate-600 mt-0.5">
                  Token #{selectedNote.appt.token_number} · {selectedNote.appt.doctor?.name} ·{' '}
                  {selectedNote.appt.clinic?.name}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedNote(null)}
                aria-label="Close visit summary"
                className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-sm">
              <div>
                <div className="text-xs font-semibold text-slate-500">Clinical Summary / Diagnosis</div>
                <p className="text-slate-900 mt-0.5">{selectedNote.note.diagnosis}</p>
              </div>
              <div>
                <div className="text-xs font-semibold text-slate-500">Medications</div>
                <p className="text-slate-900 mt-0.5 whitespace-pre-line">
                  {selectedNote.note.medications || 'None prescribed'}
                </p>
              </div>
              <div>
                <div className="text-xs font-semibold text-slate-500">Care Instructions</div>
                <p className="text-slate-700 mt-0.5 whitespace-pre-line">
                  {selectedNote.note.instructions}
                </p>
              </div>
              {selectedNote.note.follow_up && (
                <div>
                  <div className="text-xs font-semibold text-slate-500">Follow-Up</div>
                  <p className="text-slate-900 mt-0.5">{selectedNote.note.follow_up}</p>
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
              <span>Restricted to {patientInfo?.full_name} & authorized care team</span>
              <button
                type="button"
                onClick={() => setSelectedNote(null)}
                className="px-4 py-2 rounded-lg bg-slate-900 text-white font-semibold hover:bg-slate-800 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
