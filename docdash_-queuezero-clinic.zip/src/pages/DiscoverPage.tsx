import {
  Building2,
  Calendar,
  Clock,
  MapPin,
  Search,
  ShieldAlert,
  Users,
} from 'lucide-react';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { BookingModal } from '../components/BookingModal';
import { DoctorStatusIndicator } from '../components/StatusBadge';
import { WaitHeatmapPanel } from '../components/WaitHeatmapPanel';
import { useAppContext } from '../context/AppContext';
import type { Clinic, Doctor, Specialty } from '../types';

const SPECIALTIES: Array<'all' | Specialty> = [
  'all',
  'General Medicine',
  'Pediatrics',
  'Orthopedics',
  'Cardiology',
];

export function DiscoverPage() {
  const { subscribeUpdates } = useAppContext();
  const [clinics, setClinics] = useState<Clinic[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');

  const [selectedClinicId, setSelectedClinicId] = useState<string>('all');
  const [selectedSpecialty, setSelectedSpecialty] = useState<'all' | Specialty>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [bookingTarget, setBookingTarget] = useState<{
    doctor: Doctor;
    sessionId?: string;
  } | null>(null);
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});

  const fetchData = useCallback(async () => {
    try {
      const [clinicsRes, doctorsRes] = await Promise.all([
        fetch('/api/clinics'),
        fetch('/api/doctors'),
      ]);
      if (!clinicsRes.ok || !doctorsRes.ok) {
        throw new Error('Failed to load clinic directory');
      }
      const clinicsJson = await clinicsRes.json();
      const doctorsJson = await doctorsRes.json();
      setClinics(clinicsJson.clinics || []);
      setDoctors(doctorsJson.doctors || []);
      setErrorMsg('');
    } catch {
      setErrorMsg('Unable to load clinics and doctors right now. Please refresh.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
    const unsub = subscribeUpdates(() => {
      fetchData();
    });
    return unsub;
  }, [fetchData, subscribeUpdates]);

  const filteredDoctors = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return doctors.filter((doc) => {
      if (selectedClinicId !== 'all' && doc.clinic_id !== selectedClinicId) return false;
      if (selectedSpecialty !== 'all' && doc.specialty !== selectedSpecialty) return false;
      if (q) {
        const hay = `${doc.name} ${doc.specialty} ${doc.clinic.name} ${doc.qualifications}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [doctors, selectedClinicId, selectedSpecialty, searchQuery]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      {/* Calm Clinical Hero & Disclaimer */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="max-w-2xl space-y-3">
          <p className="text-xs font-semibold text-teal-800 tracking-wide">
            Outpatient Appointment & Virtual Queue
          </p>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Book your clinic token and wait from home until it is almost your turn
          </h1>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Browse our four city clinic branches, reserve a morning or evening outpatient token, and follow live consultation progress updated as each patient finishes.
          </p>
          <div className="pt-1 flex items-start gap-2 text-xs text-slate-600">
            <ShieldAlert className="w-4 h-4 text-amber-700 mt-0.5 shrink-0" aria-hidden="true" />
            <span>
              Wait times are dynamic estimates based on recent consultation pace and are not guarantees. This portal is not a substitute for emergency medical care.
            </span>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row lg:flex-col gap-3 shrink-0">
          <Link
            to="/appointments"
            className="inline-flex items-center justify-center px-5 py-2.5 rounded-lg bg-teal-700 text-white text-sm font-semibold hover:bg-teal-800 transition-colors whitespace-nowrap"
          >
            View My Appointments
          </Link>
          <a
            href="#doctor-directory"
            className="inline-flex items-center justify-center px-5 py-2.5 rounded-lg border border-slate-300 bg-white text-slate-700 text-sm font-medium hover:bg-slate-50 transition-colors whitespace-nowrap"
          >
            Browse Doctors
          </a>
        </div>
      </section>

      {errorMsg && (
        <div role="alert" className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-sm text-rose-800">
          {errorMsg}
        </div>
      )}

      {/* Clinic Branch Directory */}
      <section aria-labelledby="clinics-heading" className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
          <div>
            <h2 id="clinics-heading" className="text-xl font-semibold text-slate-900">
              City Clinic Branches
            </h2>
            <p className="text-sm text-slate-600 mt-0.5">
              Select a branch to filter doctors and live outpatient queues.
            </p>
          </div>
          {selectedClinicId !== 'all' && (
            <button
              type="button"
              onClick={() => setSelectedClinicId('all')}
              className="text-sm font-medium text-teal-800 hover:underline self-start sm:self-auto cursor-pointer"
            >
              Show all 4 branches
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {loading
            ? Array.from({ length: 4 }).map((_, i) => (
                <div
                  key={i}
                  className="bg-white border border-slate-200 rounded-xl overflow-hidden animate-pulse"
                >
                  <div className="aspect-[16/9] bg-slate-200" />
                  <div className="p-4 space-y-2.5">
                    <div className="h-4 bg-slate-200 rounded w-3/4" />
                    <div className="h-3 bg-slate-200 rounded w-1/2" />
                  </div>
                </div>
              ))
            : clinics.map((clinic) => {
                const isSelected = selectedClinicId === clinic.id;
                const imgBroken = failedImages[clinic.id];
                return (
                  <button
                    key={clinic.id}
                    type="button"
                    onClick={() =>
                      setSelectedClinicId((prev) => (prev === clinic.id ? 'all' : clinic.id))
                    }
                    className={`text-left bg-white rounded-xl overflow-hidden border transition-colors flex flex-col cursor-pointer ${
                      isSelected
                        ? 'border-teal-700 ring-1 ring-teal-700'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="aspect-[16/9] w-full bg-slate-100 relative overflow-hidden">
                      {!imgBroken ? (
                        <img
                          src={clinic.image_url}
                          alt={`${clinic.name} outpatient reception`}
                          referrerPolicy="no-referrer"
                          onError={() =>
                            setFailedImages((prev) => ({ ...prev, [clinic.id]: true }))
                          }
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-slate-100 to-teal-50 text-slate-500 p-4">
                          <Building2 className="w-8 h-8 mb-1.5 text-teal-700" aria-hidden="true" />
                          <span className="text-xs font-medium text-center">{clinic.name}</span>
                        </div>
                      )}
                    </div>

                    <div className="p-4 flex-1 flex flex-col justify-between gap-2 w-full">
                      <div>
                        <h3 className="text-sm font-semibold text-slate-900 leading-snug">
                          {clinic.name}
                        </h3>
                        <p className="text-xs text-slate-600 mt-1 flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" aria-hidden="true" />
                          <span className="truncate">{clinic.address}</span>
                        </p>
                      </div>

                      <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600 tabular-nums">
                        <span>{clinic.doctorCount ?? 2} doctors</span>
                        <span aria-hidden="true">·</span>
                        <span>{clinic.activeWaiting ?? 0} waiting today</span>
                      </div>
                    </div>
                  </button>
                );
              })}
        </div>
      </section>

      {/* Doctor & Specialty Directory */}
      <section id="doctor-directory" aria-labelledby="doctors-heading" className="space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h2 id="doctors-heading" className="text-xl font-semibold text-slate-900">
              Doctors & Live Outpatient Sessions
            </h2>
            <p className="text-sm text-slate-600 mt-0.5">
              Filter by specialty or branch and reserve the next sequential token.
            </p>
          </div>

          <div className="relative w-full lg:w-72">
            <Search
              className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <label htmlFor="doctor-search" className="sr-only">
              Search doctors or clinics
            </label>
            <input
              id="doctor-search"
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search doctor or specialty..."
              className="w-full pl-9 pr-4 py-2 rounded-lg border border-slate-300 bg-white text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
            />
          </div>
        </div>

        {/* Interactive Filter Bar */}
        <div className="flex flex-wrap items-center gap-2 p-1.5 bg-slate-100 rounded-lg w-fit max-w-full">
          {SPECIALTIES.map((spec) => {
            const active = selectedSpecialty === spec;
            return (
              <button
                key={spec}
                type="button"
                onClick={() => setSelectedSpecialty(spec)}
                className={`px-3.5 py-2 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  active
                    ? 'bg-white text-slate-900 shadow-sm font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {spec === 'all' ? 'All Specialties' : spec}
              </button>
            );
          })}
        </div>

        {/* Doctor Cards Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {Array.from({ length: 4 }).map((_, i) => (
              <div
                key={i}
                className="bg-white border border-slate-200 rounded-xl p-6 h-56 animate-pulse"
              />
            ))}
          </div>
        ) : filteredDoctors.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-10 text-center space-y-3">
            <p className="text-base font-semibold text-slate-900">
              No doctors match your current filters
            </p>
            <p className="text-sm text-slate-600">
              Try clearing your search query or switching back to all specialties and branches.
            </p>
            <button
              type="button"
              onClick={() => {
                setSelectedClinicId('all');
                setSelectedSpecialty('all');
                setSearchQuery('');
              }}
              className="inline-flex items-center px-4 py-2 rounded-lg bg-teal-700 text-white text-sm font-medium hover:bg-teal-800 cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {filteredDoctors.map((doc) => {
              const activeSess = doc.activeSession;
              const morningSess = doc.sessions.find((s) => s.period === 'morning');
              const eveningSess = doc.sessions.find((s) => s.period === 'evening');

              return (
                <article
                  key={doc.id}
                  className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between gap-5"
                >
                  <div className="space-y-3">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div>
                        <h3 className="text-lg font-semibold text-slate-900">{doc.name}</h3>
                        <p className="text-xs text-slate-600 mt-0.5">{doc.qualifications}</p>
                      </div>
                      {activeSess && (
                        <DoctorStatusIndicator
                          status={activeSess.status}
                          delayMinutes={activeSess.delay_minutes}
                        />
                      )}
                    </div>

                    {/* Zero-pill unboxed metadata */}
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-700 font-medium">
                      <span className="text-teal-800 font-semibold">{doc.specialty}</span>
                      <span aria-hidden="true" className="text-slate-300">·</span>
                      <span>{doc.clinic.name}</span>
                      <span aria-hidden="true" className="text-slate-300">·</span>
                      <span>{doc.room_number}</span>
                      <span aria-hidden="true" className="text-slate-300">·</span>
                      <span className="font-mono tabular-nums">${doc.consultation_fee} fee</span>
                    </div>

                    <p className="text-sm text-slate-600 leading-relaxed">{doc.bio}</p>
                  </div>

                  <div className="pt-4 border-t border-slate-200 space-y-4">
                    {activeSess && (
                      <div className="grid grid-cols-3 gap-3 text-xs">
                        <div>
                          <div className="text-slate-500">Current Token</div>
                          <div className="font-mono tabular-nums text-base font-semibold text-slate-900 mt-0.5">
                            {activeSess.currentTokenNumber ? `#${activeSess.currentTokenNumber}` : 'Ready'}
                          </div>
                        </div>
                        <div>
                          <div className="text-slate-500 flex items-center gap-1">
                            <Users className="w-3.5 h-3.5" aria-hidden="true" />
                            <span>In Queue</span>
                          </div>
                          <div className="font-mono tabular-nums text-base font-semibold text-slate-900 mt-0.5">
                            {activeSess.waitingCount} waiting
                          </div>
                        </div>
                        <div>
                          <div className="text-slate-500 flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5" aria-hidden="true" />
                            <span>Est. New Wait</span>
                          </div>
                          <div className="font-mono tabular-nums text-base font-semibold text-teal-800 mt-0.5">
                            ~{activeSess.estimatedNewWaitMinutes} min
                          </div>
                        </div>
                      </div>
                    )}

                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" aria-hidden="true" />
                        <span>
                          Today:{' '}
                          {morningSess ? `AM (${morningSess.start_time}–${morningSess.end_time})` : ''}
                          {morningSess && eveningSess ? ' · ' : ''}
                          {eveningSess ? `PM (${eveningSess.start_time}–${eveningSess.end_time})` : ''}
                        </span>
                      </div>

                      <button
                        type="button"
                        onClick={() =>
                          setBookingTarget({ doctor: doc, sessionId: activeSess?.id })
                        }
                        className="px-4 py-2 rounded-lg bg-teal-700 text-white text-sm font-semibold hover:bg-teal-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                      >
                        Book Token
                      </button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      {/* Optional Enhancement: Historical Wait-Time Guidance Heatmap */}
      {clinics.length > 0 && <WaitHeatmapPanel clinics={clinics} />}

      {bookingTarget && (
        <BookingModal
          doctor={bookingTarget.doctor}
          initialSessionId={bookingTarget.sessionId}
          onClose={() => setBookingTarget(null)}
        />
      )}
    </div>
  );
}
