import { Info } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { Clinic } from '../types';

interface HeatmapData {
  clinicId: string;
  disclaimer: string;
  days: string[];
  matrix: Array<{
    period: string;
    values: Array<{
      day: string;
      avgMinutes: number;
      band: 'low' | 'moderate' | 'busy';
    }>;
  }>;
}

export function WaitHeatmapPanel({ clinics }: { clinics: Clinic[] }) {
  const [selectedClinicId, setSelectedClinicId] = useState(clinics[0]?.id || 'clinic-metro');
  const [data, setData] = useState<HeatmapData | null>(null);

  useEffect(() => {
    if (!selectedClinicId) return;
    fetch(`/api/analytics/wait-heatmap?clinicId=${encodeURIComponent(selectedClinicId)}`)
      .then((r) => r.json())
      .then((res) => setData(res))
      .catch(() => {});
  }, [selectedClinicId]);

  const cellColor = (band: 'low' | 'moderate' | 'busy') => {
    if (band === 'low') return 'bg-emerald-50 text-emerald-900 border-emerald-200';
    if (band === 'moderate') return 'bg-amber-50 text-amber-900 border-amber-200';
    return 'bg-rose-50 text-rose-900 border-rose-200';
  };

  return (
    <section
      aria-labelledby="historical-heatmap-heading"
      className="bg-white border border-slate-200 rounded-xl p-6"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
        <div>
          <h2 id="historical-heatmap-heading" className="text-base font-semibold text-slate-900">
            Historical Wait-Time Guidance
          </h2>
          <p className="text-xs text-slate-600 mt-1 flex items-center gap-1.5">
            <Info className="w-3.5 h-3.5 text-slate-500 shrink-0" aria-hidden="true" />
            <span>
              {data?.disclaimer ||
                'Historical 90-day outpatient averages for general planning only. Not a live wait prediction.'}
            </span>
          </p>
        </div>

        <div className="shrink-0">
          <label htmlFor="heatmap-clinic-select" className="sr-only">
            Select clinic for historical wait guidance
          </label>
          <select
            id="heatmap-clinic-select"
            value={selectedClinicId}
            onChange={(e) => setSelectedClinicId(e.target.value)}
            className="px-3 py-2 rounded-lg border border-slate-300 bg-white text-xs font-medium text-slate-800 focus:border-teal-700 focus:outline-none"
          >
            {clinics.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {data && (
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-xs text-slate-500">
                <th className="py-2 pr-4 font-medium">Time Window</th>
                {data.days.map((day) => (
                  <th key={day} className="py-2 px-2 text-center font-medium">
                    {day}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {data.matrix.map((row) => (
                <tr key={row.period}>
                  <td className="py-2.5 pr-4 font-medium text-slate-700 whitespace-nowrap">
                    {row.period}
                  </td>
                  {row.values.map((cell) => (
                    <td key={cell.day} className="py-1.5 px-1.5 text-center">
                      <span
                        className={`inline-block w-full py-1.5 px-2 rounded border font-mono tabular-nums font-medium ${cellColor(
                          cell.band
                        )}`}
                      >
                        ~{cell.avgMinutes}m
                      </span>
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
