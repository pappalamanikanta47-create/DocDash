import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Coffee,
  Stethoscope,
  UserCheck,
  UserX,
  Volume2,
} from 'lucide-react';
import type { AppointmentStatus, DoctorSessionStatus } from '../types';

export function DoctorStatusIndicator({
  status,
  delayMinutes = 0,
}: {
  status: DoctorSessionStatus;
  delayMinutes?: number;
}) {
  if (status === 'on_break') {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-amber-50 text-amber-800 border border-amber-200 whitespace-nowrap shrink-0">
        <Coffee className="w-3.5 h-3.5" aria-hidden="true" />
        <span>On Break</span>
      </span>
    );
  }

  if (status === 'delayed' || delayMinutes > 0) {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-amber-50 text-amber-800 border border-amber-200 whitespace-nowrap shrink-0 tabular-nums">
        <AlertTriangle className="w-3.5 h-3.5" aria-hidden="true" />
        <span>Delayed{delayMinutes > 0 ? ` (+${delayMinutes} min)` : ''}</span>
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-emerald-50 text-emerald-800 border border-emerald-200 whitespace-nowrap shrink-0">
      <Stethoscope className="w-3.5 h-3.5" aria-hidden="true" />
      <span>In Consultation</span>
    </span>
  );
}

export function AppointmentStatusIndicator({
  status,
  isUrgent = false,
}: {
  status: AppointmentStatus;
  isUrgent?: boolean;
}) {
  if (status === 'in_consultation') {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-teal-50 text-teal-800 border border-teal-200 whitespace-nowrap shrink-0">
        <Stethoscope className="w-3.5 h-3.5" aria-hidden="true" />
        <span>In Consultation</span>
      </span>
    );
  }

  if (status === 'called') {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-teal-700 text-white whitespace-nowrap shrink-0">
        <Volume2 className="w-3.5 h-3.5" aria-hidden="true" />
        <span>Called Now</span>
      </span>
    );
  }

  if (status === 'checked_in') {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-emerald-50 text-emerald-800 border border-emerald-200 whitespace-nowrap shrink-0">
        <UserCheck className="w-3.5 h-3.5" aria-hidden="true" />
        <span>{isUrgent ? 'Urgent · Checked In' : 'Checked In'}</span>
      </span>
    );
  }

  if (status === 'waiting') {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-slate-100 text-slate-700 border border-slate-200 whitespace-nowrap shrink-0">
        <Clock className="w-3.5 h-3.5" aria-hidden="true" />
        <span>{isUrgent ? 'Urgent · Waiting' : 'Waiting'}</span>
      </span>
    );
  }

  if (status === 'completed') {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-slate-100 text-slate-700 border border-slate-200 whitespace-nowrap shrink-0">
        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" aria-hidden="true" />
        <span>Completed</span>
      </span>
    );
  }

  if (status === 'skipped') {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-rose-50 text-rose-800 border border-rose-200 whitespace-nowrap shrink-0">
        <UserX className="w-3.5 h-3.5" aria-hidden="true" />
        <span>Absent / Skipped</span>
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-slate-100 text-slate-500 border border-slate-200 whitespace-nowrap shrink-0">
      <span>Cancelled</span>
    </span>
  );
}
