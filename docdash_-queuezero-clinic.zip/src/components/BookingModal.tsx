import { Calendar, CheckCircle2, Clock, Info, X } from 'lucide-react';
import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';
import type { Doctor, PatientAppointment, SessionSummary } from '../types';

interface BookingModalProps {
  doctor: Doctor;
  initialSessionId?: string;
  onClose: () => void;
}

export function BookingModal({ doctor, initialSessionId, onClose }: BookingModalProps) {
  const { setActivePatientId, setRole, triggerLocalRefresh } = useAppContext();
  const navigate = useNavigate();

  const [selectedSessionId, setSelectedSessionId] = useState<string>(
    initialSessionId || doctor.sessions[0]?.id || ''
  );
  const [patientName, setPatientName] = useState('');
  const [patientPhone, setPatientPhone] = useState('');
  const [reason, setReason] = useState('');
  const [step, setStep] = useState<'form' | 'review' | 'confirmed'>('form');
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [bookedAppt, setBookedAppt] = useState<PatientAppointment | null>(null);

  const selectedSession: SessionSummary | undefined = useMemo(
    () => doctor.sessions.find((s) => s.id === selectedSessionId) || doctor.sessions[0],
    [doctor.sessions, selectedSessionId]
  );

  const validateAndProceed = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!selectedSession) {
      setErrorMsg('Please select an available clinic session.');
      return;
    }
    if (patientName.trim().length < 2) {
      setErrorMsg('Please enter the patient’s full name (at least 2 characters).');
      return;
    }
    const digits = patientPhone.replace(/\D/g, '');
    if (digits.length < 7) {
      setErrorMsg('Please enter a valid contact phone number (at least 7 digits).');
      return;
    }
    setStep('review');
  };

  const handleConfirmBooking = async () => {
    if (!selectedSession) return;
    setSubmitting(true);
    setErrorMsg('');
    try {
      const res = await fetch('/api/appointments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: selectedSession.id,
          patientName: patientName.trim(),
          patientPhone: patientPhone.trim(),
          reason: reason.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(data.error || 'Could not complete booking.');
        setStep('form');
        return;
      }
      setActivePatientId(data.patient.id);
      setRole('patient');
      setBookedAppt(data.appointment);
      setStep('confirmed');
      triggerLocalRefresh();
    } catch {
      setErrorMsg('Network error while booking. Please try again.');
      setStep('form');
    } finally {
      setSubmitting(false);
    }
  };

  const formatSessionLabel = (sess: SessionSummary) => {
    const todayIso = new Date().toISOString().slice(0, 10);
    const dayTag = sess.session_date === todayIso ? 'Today' : sess.session_date;
    const periodLabel = sess.period === 'morning' ? 'Morning' : 'Evening';
    return `${dayTag} · ${periodLabel} (${sess.start_time}–${sess.end_time})`;
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="booking-modal-title"
    >
      <div className="bg-white border border-slate-200 rounded-xl max-w-xl w-full p-6 shadow-xl my-auto">
        <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h2 id="booking-modal-title" className="text-lg font-semibold text-slate-900">
              {step === 'confirmed' ? 'Appointment Token Confirmed' : `Book Token · ${doctor.name}`}
            </h2>
            <p className="text-xs text-slate-600 mt-1">
              {doctor.specialty} · {doctor.clinic.name} · {doctor.room_number} · ${doctor.consultation_fee}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close booking dialog"
            className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorMsg && (
          <div
            role="alert"
            className="mt-4 p-3 rounded-lg bg-rose-50 border border-rose-200 text-sm text-rose-800"
          >
            {errorMsg}
          </div>
        )}

        {step === 'form' && (
          <form onSubmit={validateAndProceed} className="mt-5 space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-800 mb-2">
                Select Date & Outpatient Session
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {doctor.sessions.map((sess) => {
                  const selected = sess.id === selectedSession?.id;
                  return (
                    <button
                      key={sess.id}
                      type="button"
                      onClick={() => setSelectedSessionId(sess.id)}
                      className={`p-3 rounded-lg border text-left transition-colors cursor-pointer ${
                        selected
                          ? 'border-teal-700 bg-teal-50/70 text-slate-900'
                          : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700'
                      }`}
                    >
                      <div className="text-xs font-semibold flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-teal-700 shrink-0" aria-hidden="true" />
                        <span>{formatSessionLabel(sess)}</span>
                      </div>
                      <div className="mt-1.5 text-xs text-slate-600 font-mono tabular-nums">
                        {sess.currentTokenNumber
                          ? `Serving #${sess.currentTokenNumber} · `
                          : 'Not started · '}
                        {sess.waitingCount} waiting (~{sess.estimatedNewWaitMinutes}m est.)
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="booking-patient-name" className="block text-sm font-medium text-slate-800 mb-1.5">
                  Patient Full Name
                </label>
                <input
                  id="booking-patient-name"
                  type="text"
                  required
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  placeholder="e.g. Priya Sharma"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="booking-patient-phone" className="block text-sm font-medium text-slate-800 mb-1.5">
                  Mobile Number (for demo alerts)
                </label>
                <input
                  id="booking-patient-phone"
                  type="tel"
                  required
                  value={patientPhone}
                  onChange={(e) => setPatientPhone(e.target.value)}
                  placeholder="e.g. 555-390-1122"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-sm text-slate-900 focus:border-teal-700 focus:outline-none font-mono"
                />
              </div>
            </div>

            <div>
              <label htmlFor="booking-reason" className="block text-sm font-medium text-slate-800 mb-1.5">
                Brief Visit Reason (optional)
              </label>
              <input
                id="booking-reason"
                type="text"
                maxLength={200}
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="e.g. Follow-up blood pressure review"
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
              />
            </div>

            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-start gap-2">
              <Info className="w-4 h-4 text-slate-500 mt-0.5 shrink-0" aria-hidden="true" />
              <span>
                Only minimum contact details are stored for queue tracking. Your details are never visible to other patients.
              </span>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-lg border border-slate-300 text-sm font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-lg bg-teal-700 text-white text-sm font-semibold hover:bg-teal-800 transition-colors cursor-pointer"
              >
                Review Appointment
              </button>
            </div>
          </form>
        )}

        {step === 'review' && selectedSession && (
          <div className="mt-5 space-y-4">
            <div className="border border-slate-200 rounded-lg divide-y divide-slate-200">
              <div className="p-3.5 flex items-center justify-between text-sm">
                <span className="text-slate-600">Doctor & Specialty</span>
                <span className="font-semibold text-slate-900">
                  {doctor.name} ({doctor.specialty})
                </span>
              </div>
              <div className="p-3.5 flex items-center justify-between text-sm">
                <span className="text-slate-600">Clinic Branch</span>
                <span className="font-medium text-slate-900">{doctor.clinic.name}</span>
              </div>
              <div className="p-3.5 flex items-center justify-between text-sm">
                <span className="text-slate-600">Session</span>
                <span className="font-medium text-slate-900">{formatSessionLabel(selectedSession)}</span>
              </div>
              <div className="p-3.5 flex items-center justify-between text-sm">
                <span className="text-slate-600">Patient</span>
                <span className="font-medium text-slate-900">
                  {patientName.trim()} ({patientPhone.trim()})
                </span>
              </div>
              <div className="p-3.5 flex items-center justify-between text-sm">
                <span className="text-slate-600">Expected Token & Wait Estimate</span>
                <span className="font-mono font-semibold text-teal-800 tabular-nums">
                  Token #{selectedSession.nextTokenNumber} · ~{selectedSession.estimatedNewWaitMinutes} min est.
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Wait times are live estimates based on recent consultation pace ({doctor.ewmaMinutes} min avg) and current delays, not guarantees. For urgent medical emergencies, seek immediate emergency care.
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setStep('form')}
                disabled={submitting}
                className="px-4 py-2 rounded-lg border border-slate-300 text-sm font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Edit Details
              </button>
              <button
                type="button"
                onClick={handleConfirmBooking}
                disabled={submitting}
                className="px-5 py-2 rounded-lg bg-teal-700 text-white text-sm font-semibold hover:bg-teal-800 disabled:opacity-60 transition-colors cursor-pointer"
              >
                {submitting ? 'Confirming...' : 'Confirm & Issue Token'}
              </button>
            </div>
          </div>
        )}

        {step === 'confirmed' && bookedAppt && (
          <div className="mt-5 space-y-5">
            <div className="p-5 rounded-xl bg-teal-50 border border-teal-200 text-center">
              <CheckCircle2 className="w-8 h-8 text-teal-700 mx-auto mb-2" aria-hidden="true" />
              <div className="text-xs font-medium text-teal-800">Issued Queue Token</div>
              <div className="text-4xl font-bold font-mono tabular-nums text-slate-900 mt-1">
                #{bookedAppt.token_number}
              </div>
              <div className="mt-3 flex items-center justify-center gap-4 text-sm text-slate-700 tabular-nums">
                <span>
                  Patients ahead: <strong>{bookedAppt.patientsAhead}</strong>
                </span>
                <span aria-hidden="true">·</span>
                <span className="inline-flex items-center gap-1">
                  <Clock className="w-4 h-4 text-teal-700" aria-hidden="true" />
                  <span>
                    Est. wait: <strong>~{bookedAppt.estimatedWaitMinutes ?? 0} min</strong>
                  </span>
                </span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="w-full sm:w-auto px-4 py-2 rounded-lg border border-slate-300 text-sm font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Keep Browsing
              </button>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  navigate('/appointments');
                }}
                className="w-full sm:w-auto px-5 py-2 rounded-lg bg-teal-700 text-white text-sm font-semibold hover:bg-teal-800 cursor-pointer"
              >
                Track Live Queue in My Appointments
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
