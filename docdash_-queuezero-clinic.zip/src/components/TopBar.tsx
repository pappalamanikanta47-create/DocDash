import { Building2, Menu, ShieldCheck, Stethoscope, User, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';
import type { DemoPatient, Role } from '../types';

export function TopBar() {
  const {
    role,
    setRole,
    activePatientId,
    setActivePatientId,
    roleModalOpen,
    setRoleModalOpen,
  } = useAppContext();
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [demoPatients, setDemoPatients] = useState<DemoPatient[]>([]);

  useEffect(() => {
    if (!roleModalOpen) return;
    fetch('/api/patients/demo')
      .then((r) => r.json())
      .then((data) => {
        if (Array.isArray(data.patients)) {
          setDemoPatients(data.patients);
        }
      })
      .catch(() => {});
  }, [roleModalOpen]);

  const roleLabels: Record<Role, string> = {
    patient: 'Role: Patient',
    doctor: 'Role: Doctor',
    staff: 'Role: Staff',
  };

  const navLinks = [
    { to: '/', label: 'Discover Clinics', visible: true },
    { to: '/appointments', label: 'My Appointments', visible: true },
    { to: '/doctor', label: 'Doctor Console', visible: true },
    { to: '/staff', label: 'Staff Desk', visible: true },
  ];

  const handleSelectRole = (nextRole: Role, targetRoute: string) => {
    setRole(nextRole);
    setRoleModalOpen(false);
    setMobileMenuOpen(false);
    navigate(targetRoute);
  };

  return (
    <>
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Single-line Brand Wordmark */}
          <Link
            to="/"
            className="font-display text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0"
          >
            DocDash
          </Link>

          {/* Zone 2: Single-line Text Navigation Links */}
          <nav
            aria-label="Primary navigation"
            className="hidden md:flex items-center gap-6 text-sm font-medium"
          >
            {navLinks.map((link) => {
              const active = location.pathname === link.to;
              return (
                <Link
                  key={link.to}
                  to={link.to}
                  className={`py-1 whitespace-nowrap shrink-0 transition-colors border-b-2 ${
                    active
                      ? 'text-teal-800 border-teal-700 font-semibold'
                      : 'text-slate-600 border-transparent hover:text-slate-900 hover:border-slate-300'
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>

          {/* Zone 3: 1 Primary Action */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setRoleModalOpen(true)}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold bg-teal-700 text-white hover:bg-teal-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>{roleLabels[role]}</span>
            </button>

            <button
              type="button"
              onClick={() => setMobileMenuOpen((v) => !v)}
              aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
              aria-expanded={mobileMenuOpen}
              className="md:hidden inline-flex items-center justify-center p-2 rounded-lg text-slate-700 hover:bg-slate-100"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <nav
            aria-label="Mobile navigation"
            className="md:hidden border-t border-slate-200 bg-white px-4 py-3 space-y-1"
          >
            {navLinks.map((link) => {
              const active = location.pathname === link.to;
              return (
                <Link
                  key={link.to}
                  to={link.to}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`block px-3 py-2.5 rounded-lg text-sm font-medium ${
                    active ? 'bg-teal-50 text-teal-800 font-semibold' : 'text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>
        )}
      </header>

      {/* Role & Demo Account Switcher Modal */}
      {roleModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="role-switcher-title"
        >
          <div className="bg-white border border-slate-200 rounded-xl max-w-lg w-full p-6 shadow-xl">
            <div className="flex items-start justify-between gap-4 mb-5">
              <div>
                <h2 id="role-switcher-title" className="text-lg font-semibold text-slate-900">
                  Switch Demo Role & Account
                </h2>
                <p className="text-sm text-slate-600 mt-1">
                  Each role has distinct views and permissions. Patient data remains strictly private.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setRoleModalOpen(false)}
                aria-label="Close role switcher"
                className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <button
                type="button"
                onClick={() => handleSelectRole('patient', '/appointments')}
                className={`w-full text-left p-4 rounded-lg border transition-colors flex items-start gap-3.5 cursor-pointer ${
                  role === 'patient'
                    ? 'border-teal-700 bg-teal-50/50'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <User className="w-5 h-5 text-teal-700 mt-0.5 shrink-0" aria-hidden="true" />
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-slate-900">
                    Patient View
                  </div>
                  <div className="text-xs text-slate-600 mt-0.5">
                    Browse clinics, book sequential tokens, track live wait estimates, and view only your own alerts.
                  </div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleSelectRole('doctor', '/doctor')}
                className={`w-full text-left p-4 rounded-lg border transition-colors flex items-start gap-3.5 cursor-pointer ${
                  role === 'doctor'
                    ? 'border-teal-700 bg-teal-50/50'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <Stethoscope className="w-5 h-5 text-teal-700 mt-0.5 shrink-0" aria-hidden="true" />
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-slate-900">
                    Doctor Console (Dr. Priya Mehta · Cardiology)
                  </div>
                  <div className="text-xs text-slate-600 mt-0.5">
                    Call next patient, complete consultations for EWMA timing, skip absentees, and report delays or breaks.
                  </div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleSelectRole('staff', '/staff')}
                className={`w-full text-left p-4 rounded-lg border transition-colors flex items-start gap-3.5 cursor-pointer ${
                  role === 'staff'
                    ? 'border-teal-700 bg-teal-50/50'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <Building2 className="w-5 h-5 text-teal-700 mt-0.5 shrink-0" aria-hidden="true" />
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-slate-900">
                    Clinic Staff Desk
                  </div>
                  <div className="text-xs text-slate-600 mt-0.5">
                    Monitor all 4 branches, assist patient check-in, and perform audited urgent-patient escalations.
                  </div>
                </div>
              </button>
            </div>

            {/* Active Patient Account Switcher */}
            <div className="mt-6 pt-5 border-t border-slate-200">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 mb-2.5">
                <ShieldCheck className="w-4 h-4 text-teal-700" aria-hidden="true" />
                <span>Active Patient Account (for Patient View)</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {demoPatients.map((pat) => {
                  const selected = pat.id === activePatientId;
                  return (
                    <button
                      key={pat.id}
                      type="button"
                      onClick={() => {
                        setActivePatientId(pat.id);
                        setRole('patient');
                      }}
                      className={`px-3 py-2 rounded-lg border text-left transition-colors cursor-pointer ${
                        selected
                          ? 'border-teal-700 bg-teal-50 text-teal-900'
                          : 'border-slate-200 hover:border-slate-300 text-slate-700'
                      }`}
                    >
                      <div className="text-xs font-semibold truncate">{pat.full_name}</div>
                      <div className="text-[11px] text-slate-500 font-mono tabular-nums mt-0.5">
                        {pat.maskedPhone} · {pat.appointmentCount} visits
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
