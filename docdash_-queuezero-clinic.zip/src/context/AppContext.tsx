import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import type { Role } from '../types';

interface LiveEvent {
  type: string;
  sessionId?: string;
  clinicId?: string;
  doctorId?: string;
  timestamp: string;
}

interface AppContextValue {
  role: Role;
  setRole: (role: Role) => void;
  activePatientId: string;
  setActivePatientId: (id: string) => void;
  activeDoctorId: string;
  setActiveDoctorId: (id: string) => void;
  wsConnected: boolean;
  lastSyncAt: string;
  roleModalOpen: boolean;
  setRoleModalOpen: (open: boolean) => void;
  subscribeUpdates: (listener: (event: LiveEvent) => void) => () => void;
  triggerLocalRefresh: () => void;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [role, setRoleState] = useState<Role>(() => {
    const saved = localStorage.getItem('docdash_role');
    return saved === 'doctor' || saved === 'staff' ? saved : 'patient';
  });

  const [activePatientId, setActivePatientIdState] = useState<string>(() => {
    return localStorage.getItem('docdash_patient_id') || 'pat-aarav';
  });

  const [activeDoctorId, setActiveDoctorIdState] = useState<string>(() => {
    return localStorage.getItem('docdash_doctor_id') || 'doc-mehta';
  });

  const [wsConnected, setWsConnected] = useState(false);
  const [lastSyncAt, setLastSyncAt] = useState(() => new Date().toISOString());
  const [roleModalOpen, setRoleModalOpen] = useState(false);

  const listenersRef = useRef<Set<(event: LiveEvent) => void>>(new Set());

  const setRole = useCallback((next: Role) => {
    setRoleState(next);
    localStorage.setItem('docdash_role', next);
  }, []);

  const setActivePatientId = useCallback((id: string) => {
    setActivePatientIdState(id);
    localStorage.setItem('docdash_patient_id', id);
  }, []);

  const setActiveDoctorId = useCallback((id: string) => {
    setActiveDoctorIdState(id);
    localStorage.setItem('docdash_doctor_id', id);
  }, []);

  const notifyListeners = useCallback((evt: LiveEvent) => {
    setLastSyncAt(evt.timestamp || new Date().toISOString());
    for (const listener of listenersRef.current) {
      listener(evt);
    }
  }, []);

  const subscribeUpdates = useCallback((listener: (event: LiveEvent) => void) => {
    listenersRef.current.add(listener);
    return () => {
      listenersRef.current.delete(listener);
    };
  }, []);

  const triggerLocalRefresh = useCallback(() => {
    notifyListeners({ type: 'local:refresh', timestamp: new Date().toISOString() });
  }, [notifyListeners]);

  useEffect(() => {
    let ws: WebSocket | null = null;
    let reconnectTimer: number | null = null;
    let isDisposed = false;

    const connect = () => {
      if (isDisposed) return;
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      try {
        ws = new WebSocket(wsUrl);
        ws.onopen = () => {
          if (!isDisposed) setWsConnected(true);
        };
        ws.onmessage = (msg) => {
          try {
            const parsed = JSON.parse(msg.data) as LiveEvent;
            notifyListeners(parsed);
          } catch {
            // ignore non-JSON frames
          }
        };
        ws.onclose = () => {
          if (!isDisposed) {
            setWsConnected(false);
            reconnectTimer = window.setTimeout(connect, 2500);
          }
        };
        ws.onerror = () => {
          ws?.close();
        };
      } catch {
        setWsConnected(false);
        reconnectTimer = window.setTimeout(connect, 3000);
      }
    };

    connect();

    // Lightweight 3-second fallback poll in case a proxy blocks WebSockets
    const pollId = window.setInterval(() => {
      notifyListeners({ type: 'poll:tick', timestamp: new Date().toISOString() });
    }, 3000);

    return () => {
      isDisposed = true;
      if (reconnectTimer) window.clearTimeout(reconnectTimer);
      window.clearInterval(pollId);
      ws?.close();
    };
  }, [notifyListeners]);

  return (
    <AppContext.Provider
      value={{
        role,
        setRole,
        activePatientId,
        setActivePatientId,
        activeDoctorId,
        setActiveDoctorId,
        wsConnected,
        lastSyncAt,
        roleModalOpen,
        setRoleModalOpen,
        subscribeUpdates,
        triggerLocalRefresh,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useAppContext must be used inside AppProvider');
  return ctx;
}
