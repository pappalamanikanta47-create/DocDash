export type Role = 'patient' | 'doctor' | 'staff';

export type Specialty =
  | 'General Medicine'
  | 'Pediatrics'
  | 'Orthopedics'
  | 'Cardiology';

export type DoctorSessionStatus = 'in_consultation' | 'on_break' | 'delayed';

export type AppointmentStatus =
  | 'waiting'
  | 'checked_in'
  | 'called'
  | 'in_consultation'
  | 'completed'
  | 'skipped'
  | 'cancelled';

export interface Clinic {
  id: string;
  name: string;
  branch_code: string;
  address: string;
  district: string;
  phone: string;
  latitude: number;
  longitude: number;
  image_url: string;
  opening_hours: string;
  doctorCount?: number;
  specialties?: string[];
  activeWaiting?: number;
}

export interface SessionSummary {
  id: string;
  session_date: string;
  period: 'morning' | 'evening';
  start_time: string;
  end_time: string;
  status: DoctorSessionStatus;
  delay_minutes: number;
  break_minutes: number;
  currentTokenNumber: number | null;
  waitingCount: number;
  nextTokenNumber: number;
  estimatedNewWaitMinutes: number;
  updated_at: string;
}

export interface Doctor {
  id: string;
  clinic_id: string;
  name: string;
  specialty: Specialty;
  qualifications: string;
  room_number: string;
  consultation_fee: number;
  historical_avg_minutes: number;
  bio: string;
  clinic: Clinic;
  ewmaMinutes: number;
  activeSession: SessionSummary | null;
  sessions: SessionSummary[];
}

export interface DemoPatient {
  id: string;
  full_name: string;
  maskedPhone: string;
  phone: string;
  appointmentCount: number;
}

export interface VisitNote {
  id: string;
  appointment_id: string;
  doctor_id: string;
  patient_id: string;
  diagnosis: string;
  medications: string;
  instructions: string;
  follow_up: string | null;
  created_at: string;
}

export interface PatientAppointment {
  id: string;
  session_id: string;
  patient_id: string;
  token_number: number;
  queue_order: number;
  status: AppointmentStatus;
  is_urgent: number;
  urgent_reason: string | null;
  reason: string | null;
  checked_in_at: string | null;
  checkin_method: string | null;
  called_at: string | null;
  started_at: string | null;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
  session: {
    id: string;
    session_date: string;
    period: 'morning' | 'evening';
    start_time: string;
    end_time: string;
    status: DoctorSessionStatus;
    delay_minutes: number;
    break_minutes: number;
    updated_at: string;
  } | null;
  doctor: {
    id: string;
    name: string;
    specialty: Specialty;
    room_number: string;
    consultation_fee: number;
  } | null;
  clinic: Clinic | null;
  currentTokenNumber: number | null;
  ewmaMinutes: number | null;
  queuePosition: number | null;
  patientsAhead: number;
  estimatedWaitMinutes: number | null;
  lastUpdated: string;
  visitNote: VisitNote | null;
}

export interface NotificationItem {
  id: string;
  patient_id: string;
  appointment_id: string;
  type: string;
  channel: string;
  title: string;
  message: string;
  is_read: number;
  created_at: string;
}

export interface QueueAppointmentItem {
  id: string;
  session_id: string;
  patient_id: string;
  patientName: string;
  patientPhoneMasked: string;
  token_number: number;
  queue_order: number;
  status: AppointmentStatus;
  is_urgent: number;
  urgent_reason: string | null;
  reason: string | null;
  checked_in_at: string | null;
  checkin_method: string | null;
  called_at: string | null;
  started_at: string | null;
  completed_at: string | null;
  queuePosition: number | null;
  patientsAhead: number;
  estimatedWaitMinutes: number | null;
  visitNote: VisitNote | null;
}

export interface AuditLogItem {
  id: string;
  session_id: string;
  appointment_id: string | null;
  actor_role: string;
  actor_name: string;
  action: string;
  details: string;
  created_at: string;
  doctor_name?: string;
  clinic_name?: string;
}
