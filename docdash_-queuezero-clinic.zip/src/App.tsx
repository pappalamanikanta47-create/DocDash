import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { TopBar } from './components/TopBar';
import { AppProvider } from './context/AppContext';
import { DiscoverPage } from './pages/DiscoverPage';
import { DoctorConsolePage } from './pages/DoctorConsolePage';
import { MyAppointmentsPage } from './pages/MyAppointmentsPage';
import { StaffOverviewPage } from './pages/StaffOverviewPage';

export default function App() {
  return (
    <BrowserRouter>
      <AppProvider>
        <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
          <TopBar />
          <main className="flex-1">
            <Routes>
              <Route path="/" element={<DiscoverPage />} />
              <Route path="/appointments" element={<MyAppointmentsPage />} />
              <Route path="/doctor" element={<DoctorConsolePage />} />
              <Route path="/staff" element={<StaffOverviewPage />} />
            </Routes>
          </main>
          <footer className="border-t border-slate-200 bg-white py-6 mt-12">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-slate-500">
              <span>
                DocDash: QueueZero Clinic · Outpatient Queue & Booking Demo
              </span>
              <span>
                Wait times are live estimates, not guarantees. Not intended for medical emergencies.
              </span>
            </div>
          </footer>
        </div>
      </AppProvider>
    </BrowserRouter>
  );
}
