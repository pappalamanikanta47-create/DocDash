# DocDash: QueueZero Clinic

Outpatient clinic appointment booking, live virtual queue tracking, and clinical session management.

## Local Setup

1. Install dependencies:
   ```bash
   npm install
   ```
2. Start the full-stack development server (Express + WebSockets + Vite on port 3000):
   ```bash
   npm run dev
   ```
3. Build and run for production:
   ```bash
   npm run build
   npm start
   ```

No paid external services or API keys are required for the core demo. SQLite stores data locally in `data/docdash.db` (configurable via `DB_PATH`).

## Demo Accounts & Roles

Use the **Role** button in the top bar to switch between three distinct role-aware views:

- **Patient** (`/`, `/appointments`):
  - Pre-seeded accounts: **Aarav Patel** (`•••-•••-8910`) and **Maya Lin** (`•••-•••-2039`), or book a brand-new token with any name and phone number.
  - Strictly scoped so each patient only sees their own appointments, wait estimates, visit summaries, and simulated alerts.
- **Doctor Console** (`/doctor`):
  - Defaults to **Dr. Priya Mehta (Cardiology · Metro Central Medical Hub)** where Token `#11` is currently in consultation and `#12–#13` are waiting.
  - Supports **Call Next Patient**, **Mark Consultation Complete** (updating EWMA pace), **Mark Patient Absent / Skip**, **Recall**, **Delay 10 Minutes**, **On Break / In Consultation**, and attaching visit summaries/prescriptions.
- **Clinic Staff Desk** (`/staff`):
  - Displays all 4 city branches and 8 doctors, supports front-desk **Check-In Assistance**, and provides audited **Urgent-Patient Escalation** with automatic wait recalculation.

## Implemented Features & Simulated Integrations

- **Wait Time & EWMA Engine**: Computes `estimated wait = patients ahead × EWMA consultation duration + doctor delay` (plus break buffer when on break, never negative).
- **Live Updates**: WebSocket broadcasts (`/ws`) pushed from server mutations, paired with a 3-second fallback poll.
- **Simulated Alerts**: In-app notification panel automatically generates simulated SMS/Push alerts when a patient is 2 positions away or called (clearly labeled as simulated; no external SMS is sent).
- **Optional Enhancements**: Opt-in 500m geolocation check-in with explicit consent and manual fallback; restricted visit summary/prescription attachments; historical average wait-time heatmap (planning guidance only).
