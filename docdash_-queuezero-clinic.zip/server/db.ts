import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';

const dataDir = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = process.env.DB_PATH || path.join(dataDir, 'docdash.db');

export function createDatabase(): Database.Database {
  const db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  initSchema(db);
  seedIfEmpty(db);
  return db;
}

function initSchema(db: Database.Database): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS clinics (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      branch_code TEXT NOT NULL,
      address TEXT NOT NULL,
      district TEXT NOT NULL,
      phone TEXT NOT NULL,
      latitude REAL NOT NULL,
      longitude REAL NOT NULL,
      image_url TEXT NOT NULL,
      opening_hours TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS doctors (
      id TEXT PRIMARY KEY,
      clinic_id TEXT NOT NULL REFERENCES clinics(id),
      name TEXT NOT NULL,
      specialty TEXT NOT NULL,
      qualifications TEXT NOT NULL,
      room_number TEXT NOT NULL,
      consultation_fee INTEGER NOT NULL,
      historical_avg_minutes REAL NOT NULL,
      bio TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS clinic_sessions (
      id TEXT PRIMARY KEY,
      doctor_id TEXT NOT NULL REFERENCES doctors(id),
      clinic_id TEXT NOT NULL REFERENCES clinics(id),
      session_date TEXT NOT NULL,
      period TEXT NOT NULL CHECK (period IN ('morning', 'evening')),
      start_time TEXT NOT NULL,
      end_time TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'in_consultation' CHECK (status IN ('in_consultation', 'on_break', 'delayed')),
      delay_minutes INTEGER NOT NULL DEFAULT 0,
      break_minutes INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS patients (
      id TEXT PRIMARY KEY,
      full_name TEXT NOT NULL,
      phone TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS appointments (
      id TEXT PRIMARY KEY,
      session_id TEXT NOT NULL REFERENCES clinic_sessions(id),
      patient_id TEXT NOT NULL REFERENCES patients(id),
      token_number INTEGER NOT NULL,
      queue_order INTEGER NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('waiting', 'checked_in', 'called', 'in_consultation', 'completed', 'skipped', 'cancelled')),
      is_urgent INTEGER NOT NULL DEFAULT 0,
      urgent_reason TEXT,
      reason TEXT,
      checked_in_at TEXT,
      checkin_method TEXT,
      called_at TEXT,
      started_at TEXT,
      completed_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(session_id, token_number)
    );

    CREATE INDEX IF NOT EXISTS idx_appointments_session ON appointments(session_id, status, queue_order);
    CREATE INDEX IF NOT EXISTS idx_appointments_patient ON appointments(patient_id, created_at);

    CREATE TABLE IF NOT EXISTS consultation_durations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      doctor_id TEXT NOT NULL REFERENCES doctors(id),
      session_id TEXT NOT NULL REFERENCES clinic_sessions(id),
      appointment_id TEXT REFERENCES appointments(id),
      duration_minutes REAL NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS queue_audit_logs (
      id TEXT PRIMARY KEY,
      session_id TEXT NOT NULL REFERENCES clinic_sessions(id),
      appointment_id TEXT REFERENCES appointments(id),
      actor_role TEXT NOT NULL,
      actor_name TEXT NOT NULL,
      action TEXT NOT NULL,
      details TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      appointment_id TEXT NOT NULL REFERENCES appointments(id),
      type TEXT NOT NULL,
      channel TEXT NOT NULL,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS visit_notes (
      id TEXT PRIMARY KEY,
      appointment_id TEXT NOT NULL UNIQUE REFERENCES appointments(id),
      doctor_id TEXT NOT NULL REFERENCES doctors(id),
      patient_id TEXT NOT NULL REFERENCES patients(id),
      diagnosis TEXT NOT NULL,
      medications TEXT NOT NULL,
      instructions TEXT NOT NULL,
      follow_up TEXT,
      created_at TEXT NOT NULL
    );
  `);
}

function getLocalDateIso(offsetDays = 0): string {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function minutesAgoIso(mins: number): string {
  return new Date(Date.now() - mins * 60_000).toISOString();
}

function seedIfEmpty(db: Database.Database): void {
  const countRow = db.prepare('SELECT COUNT(*) as cnt FROM clinics').get() as { cnt: number };
  if (countRow.cnt > 0) {
    return;
  }

  const today = getLocalDateIso(0);
  const tomorrow = getLocalDateIso(1);
  const now = new Date().toISOString();

  const tx = db.transaction(() => {
    const insertClinic = db.prepare(`
      INSERT INTO clinics (id, name, branch_code, address, district, phone, latitude, longitude, image_url, opening_hours)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    insertClinic.run(
      'clinic-metro',
      'Metro Central Medical Hub',
      'MC-01',
      '210 Civic Plaza, Suite 200',
      'Downtown',
      '+1 (555) 301-1100',
      37.7749,
      -122.4194,
      '/src/assets/images/clinic_metro_central_1795096432722.jpg',
      'Mon–Sat · 08:30–20:30'
    );
    insertClinic.run(
      'clinic-westside',
      'Westside Family & Pediatric Center',
      'WF-02',
      '840 Laurel Avenue',
      'Westside',
      '+1 (555) 301-2200',
      37.7835,
      -122.4460,
      '/src/assets/images/clinic_westside_pediatrics_1795096433098.jpg',
      'Mon–Sat · 08:30–20:00'
    );
    insertClinic.run(
      'clinic-northgate',
      'Northgate Orthopedic Institute',
      'NO-03',
      '455 Summit Boulevard',
      'Northgate',
      '+1 (555) 301-3300',
      37.7980,
      -122.4230,
      '/src/assets/images/clinic_northgate_ortho_1795096433245.jpg',
      'Mon–Sat · 09:00–20:00'
    );
    insertClinic.run(
      'clinic-harborview',
      'Harborview Heart & Wellness Clinic',
      'HH-04',
      '120 Embarcadero Way',
      'Harborview',
      '+1 (555) 301-4400',
      37.7955,
      -122.3937,
      '/src/assets/images/clinic_harborview_heart_1795096432893.jpg',
      'Mon–Fri · 08:30–20:00'
    );

    const insertDoctor = db.prepare(`
      INSERT INTO doctors (id, clinic_id, name, specialty, qualifications, room_number, consultation_fee, historical_avg_minutes, bio)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    insertDoctor.run(
      'doc-mehta',
      'clinic-metro',
      'Dr. Priya Mehta',
      'Cardiology',
      'MD, FACC · Senior Interventional Cardiologist',
      'Suite 204',
      95,
      12,
      'Preventive cardiology, hypertension management, and non-invasive cardiac diagnostics.'
    );
    insertDoctor.run(
      'doc-chen',
      'clinic-metro',
      'Dr. Marcus Chen',
      'General Medicine',
      'MD, FACP · Internal & Primary Care',
      'Suite 108',
      65,
      10,
      'Adult acute visits, metabolic health screenings, and longitudinal primary care.'
    );
    insertDoctor.run(
      'doc-rivera',
      'clinic-westside',
      'Dr. Elena Rivera',
      'Pediatrics',
      'MD, FAAP · Child & Adolescent Health',
      'Room 12',
      75,
      12,
      'Well-child checkups, pediatric respiratory care, and childhood immunizations.'
    );
    insertDoctor.run(
      'doc-okafor',
      'clinic-westside',
      'Dr. Samuel Okafor',
      'General Medicine',
      'MBBS, MD · Family Physician',
      'Room 15',
      60,
      11,
      'Comprehensive family medicine, fever triage, and chronic condition follow-ups.'
    );
    insertDoctor.run(
      'doc-kowalski',
      'clinic-northgate',
      'Dr. Viktor Kowalski',
      'Orthopedics',
      'MD, MS Ortho · Joint & Sports Injury',
      'Pavilion B1',
      110,
      14,
      'Knee, shoulder, and ligament injury evaluation with conservative rehabilitation planning.'
    );
    insertDoctor.run(
      'doc-nair',
      'clinic-northgate',
      'Dr. Ananya Nair',
      'Orthopedics',
      'MD · Spine & Musculoskeletal Specialist',
      'Pavilion B3',
      105,
      15,
      'Posture-related back pain, fracture follow-ups, and outpatient joint care.'
    );
    insertDoctor.run(
      'doc-alvarez',
      'clinic-harborview',
      'Dr. Sofia Alvarez',
      'Cardiology',
      'MD · Clinical Echocardiography & Arrhythmia',
      'Suite 302',
      100,
      13,
      'Lipid disorders, palpitations, and post-procedure cardiac outpatient follow-up.'
    );
    insertDoctor.run(
      'doc-bennett',
      'clinic-harborview',
      'Dr. Liam Bennett',
      'Pediatrics',
      'MD · Pediatric Allergy & General Pediatrics',
      'Suite 305',
      70,
      11,
      'Pediatric asthma, seasonal allergies, and developmental outpatient consultations.'
    );

    const insertSession = db.prepare(`
      INSERT INTO clinic_sessions (id, doctor_id, clinic_id, session_date, period, start_time, end_time, status, delay_minutes, break_minutes, is_active, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const doctorsMeta = [
      { id: 'doc-mehta', clinic: 'clinic-metro', status: 'in_consultation', delay: 0, brk: 0 },
      { id: 'doc-chen', clinic: 'clinic-metro', status: 'in_consultation', delay: 0, brk: 0 },
      { id: 'doc-rivera', clinic: 'clinic-westside', status: 'in_consultation', delay: 5, brk: 0 },
      { id: 'doc-okafor', clinic: 'clinic-westside', status: 'on_break', delay: 0, brk: 10 },
      { id: 'doc-kowalski', clinic: 'clinic-northgate', status: 'delayed', delay: 10, brk: 0 },
      { id: 'doc-nair', clinic: 'clinic-northgate', status: 'in_consultation', delay: 0, brk: 0 },
      { id: 'doc-alvarez', clinic: 'clinic-harborview', status: 'in_consultation', delay: 0, brk: 0 },
      { id: 'doc-bennett', clinic: 'clinic-harborview', status: 'in_consultation', delay: 0, brk: 0 },
    ];

    for (const d of doctorsMeta) {
      // Today Morning (active session)
      insertSession.run(
        `sess-${d.id}-today-am`,
        d.id,
        d.clinic,
        today,
        'morning',
        '09:00',
        '13:00',
        d.status,
        d.delay,
        d.brk,
        1,
        now
      );
      // Today Evening (upcoming)
      insertSession.run(
        `sess-${d.id}-today-pm`,
        d.id,
        d.clinic,
        today,
        'evening',
        '16:00',
        '20:00',
        'in_consultation',
        0,
        0,
        1,
        now
      );
      // Tomorrow Morning
      insertSession.run(
        `sess-${d.id}-tmrw-am`,
        d.id,
        d.clinic,
        tomorrow,
        'morning',
        '09:00',
        '13:00',
        'in_consultation',
        0,
        0,
        1,
        now
      );
      // Tomorrow Evening
      insertSession.run(
        `sess-${d.id}-tmrw-pm`,
        d.id,
        d.clinic,
        tomorrow,
        'evening',
        '16:00',
        '20:00',
        'in_consultation',
        0,
        0,
        1,
        now
      );
    }

    const insertPatient = db.prepare(`
      INSERT INTO patients (id, full_name, phone, created_at)
      VALUES (?, ?, ?, ?)
    `);

    const seedPatients = [
      ['pat-aarav', 'Aarav Patel', '5552348910'],
      ['pat-maya', 'Maya Lin', '5554812039'],
      ['pat-david', 'David Kim', '5556129941'],
      ['pat-claire', 'Claire Brooks', '5557023318'],
      ['pat-rohan', 'Rohan Sharma', '5558145520'],
      ['pat-hana', 'Hana Sato', '5559231104'],
      ['pat-lucas', 'Lucas Meyer', '5553048821'],
      ['pat-nina', 'Nina Kapoor', '5556674219'],
      ['pat-omar', 'Omar Hassan', '5557719034'],
      ['pat-grace', 'Grace Cho', '5551193847'],
      ['pat-ethan', 'Ethan Reed', '5552287612'],
      ['pat-zara', 'Zara Ali', '5553391045'],
      ['pat-leo', 'Leo Vance', '5554409283'],
      ['pat-sofia', 'Sofia Rossi', '5555512938'],
      ['pat-noah', 'Noah Park', '5556623819'],
      ['pat-ava', 'Ava Singh', '5557734920'],
    ];

    for (const [id, name, phone] of seedPatients) {
      insertPatient.run(id, name, phone, minutesAgoIso(180));
    }

    const insertAppt = db.prepare(`
      INSERT INTO appointments (
        id, session_id, patient_id, token_number, queue_order, status,
        is_urgent, urgent_reason, reason, checked_in_at, checkin_method,
        called_at, started_at, completed_at, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const insertDuration = db.prepare(`
      INSERT INTO consultation_durations (doctor_id, session_id, appointment_id, duration_minutes, created_at)
      VALUES (?, ?, ?, ?, ?)
    `);

    // 1) Dr. Priya Mehta (Cardiology, Metro Central) — Tokens #1..#13
    // #1..#9 completed, #10 skipped, #11 in_consultation, #12 waiting, #13 waiting
    // So the next booked patient gets Token #14 with 3 ahead (#11, #12, #13) and ~36 min wait!
    const mehtaDurations = [11, 13, 12, 11, 13, 12, 12, 11, 13];
    const mehtaPatients = [
      'pat-david', 'pat-claire', 'pat-rohan', 'pat-hana', 'pat-lucas',
      'pat-nina', 'pat-omar', 'pat-grace', 'pat-ethan', 'pat-zara',
      'pat-leo', 'pat-sofia', 'pat-noah'
    ];
    mehtaPatients.forEach((patId, idx) => {
      const token = idx + 1;
      const apptId = `appt-mehta-${token}`;
      const order = token * 10;
      if (token <= 9) {
        const startAgo = (14 - token) * 14;
        const dur = mehtaDurations[idx];
        insertAppt.run(
          apptId,
          'sess-doc-mehta-today-am',
          patId,
          token,
          order,
          'completed',
          0,
          null,
          'Routine cardiac checkup',
          minutesAgoIso(startAgo + 15),
          'manual',
          minutesAgoIso(startAgo + 1),
          minutesAgoIso(startAgo),
          minutesAgoIso(startAgo - dur),
          minutesAgoIso(180),
          minutesAgoIso(startAgo - dur)
        );
        insertDuration.run('doc-mehta', 'sess-doc-mehta-today-am', apptId, dur, minutesAgoIso(startAgo - dur));
      } else if (token === 10) {
        insertAppt.run(
          apptId,
          'sess-doc-mehta-today-am',
          patId,
          10,
          order,
          'skipped',
          0,
          null,
          'BP follow-up',
          null,
          null,
          minutesAgoIso(16),
          null,
          null,
          minutesAgoIso(150),
          minutesAgoIso(12)
        );
      } else if (token === 11) {
        insertAppt.run(
          apptId,
          'sess-doc-mehta-today-am',
          patId,
          11,
          order,
          'in_consultation',
          0,
          null,
          'ECG & chest tightness review',
          minutesAgoIso(25),
          'geolocation',
          minutesAgoIso(6),
          minutesAgoIso(5),
          null,
          minutesAgoIso(140),
          minutesAgoIso(5)
        );
      } else {
        insertAppt.run(
          apptId,
          'sess-doc-mehta-today-am',
          patId,
          token,
          order,
          token === 12 ? 'checked_in' : 'waiting',
          0,
          null,
          token === 12 ? 'Medication renewal' : 'Hypertension review',
          token === 12 ? minutesAgoIso(10) : null,
          token === 12 ? 'manual' : null,
          null,
          null,
          null,
          minutesAgoIso(120 - token * 2),
          minutesAgoIso(20)
        );
      }
    });

    // 2) Dr. Marcus Chen (General Medicine, Metro Central) — Tokens #1..#6
    // Aarav Patel (#1 completed with visit note!), #2 completed, #3 in_consultation, #4..#6 waiting
    const chenSeed = [
      { t: 1, pat: 'pat-aarav', st: 'completed', dur: 10, reason: 'Seasonal fatigue & lab review' },
      { t: 2, pat: 'pat-maya', st: 'completed', dur: 11, reason: 'Annual physical' },
      { t: 3, pat: 'pat-david', st: 'in_consultation', dur: 0, reason: 'Persistent cough' },
      { t: 4, pat: 'pat-claire', st: 'checked_in', dur: 0, reason: 'Blood pressure check' },
      { t: 5, pat: 'pat-rohan', st: 'waiting', dur: 0, reason: 'Migraine follow-up' },
      { t: 6, pat: 'pat-hana', st: 'waiting', dur: 0, reason: 'Travel vaccination consult' },
    ];
    for (const item of chenSeed) {
      const apptId = `appt-chen-${item.t}`;
      const isDone = item.st === 'completed';
      const isActive = item.st === 'in_consultation';
      insertAppt.run(
        apptId,
        'sess-doc-chen-today-am',
        item.pat,
        item.t,
        item.t * 10,
        item.st,
        0,
        null,
        item.reason,
        item.t <= 4 ? minutesAgoIso(60 - item.t * 5) : null,
        item.t <= 4 ? 'manual' : null,
        isDone || isActive ? minutesAgoIso(40 - item.t * 5) : null,
        isDone || isActive ? minutesAgoIso(39 - item.t * 5) : null,
        isDone ? minutesAgoIso(29 - item.t * 5) : null,
        minutesAgoIso(150),
        minutesAgoIso(10)
      );
      if (isDone) {
        insertDuration.run('doc-chen', 'sess-doc-chen-today-am', apptId, item.dur, minutesAgoIso(29 - item.t * 5));
      }
    }

    // 3) Dr. Elena Rivera (Pediatrics, Westside) — Tokens #1..#6
    // #1..#3 completed, #4 in_consultation, #5 waiting, #6 Aarav Patel waiting (2 positions away!)
    const riveraSeed = [
      { t: 1, pat: 'pat-lucas', st: 'completed', dur: 12, reason: 'Pediatric wellness check' },
      { t: 2, pat: 'pat-nina', st: 'completed', dur: 13, reason: 'Ear discomfort check' },
      { t: 3, pat: 'pat-omar', st: 'completed', dur: 11, reason: 'School immunization form' },
      { t: 4, pat: 'pat-grace', st: 'in_consultation', dur: 0, reason: 'Fever & sore throat' },
      { t: 5, pat: 'pat-maya', st: 'checked_in', dur: 0, reason: 'Follow-up respiratory exam' },
      { t: 6, pat: 'pat-aarav', st: 'waiting', dur: 0, reason: 'Pediatric allergy consultation' },
    ];
    for (const item of riveraSeed) {
      const apptId = `appt-rivera-${item.t}`;
      const isDone = item.st === 'completed';
      const isActive = item.st === 'in_consultation';
      insertAppt.run(
        apptId,
        'sess-doc-rivera-today-am',
        item.pat,
        item.t,
        item.t * 10,
        item.st,
        0,
        null,
        item.reason,
        item.t <= 5 ? minutesAgoIso(50 - item.t * 4) : null,
        item.t <= 5 ? 'manual' : null,
        isDone || isActive ? minutesAgoIso(35 - item.t * 4) : null,
        isDone || isActive ? minutesAgoIso(34 - item.t * 4) : null,
        isDone ? minutesAgoIso(22 - item.t * 4) : null,
        minutesAgoIso(130),
        minutesAgoIso(8)
      );
      if (isDone) {
        insertDuration.run('doc-rivera', 'sess-doc-rivera-today-am', apptId, item.dur, minutesAgoIso(22 - item.t * 4));
      }
    }

    // 4) Dr. Viktor Kowalski (Orthopedics, Northgate) — Tokens #1..#5
    const kowalskiSeed = [
      { t: 1, pat: 'pat-ethan', st: 'completed', dur: 14, reason: 'Knee MRI review' },
      { t: 2, pat: 'pat-zara', st: 'completed', dur: 15, reason: 'Ankle sprain follow-up' },
      { t: 3, pat: 'pat-leo', st: 'in_consultation', dur: 0, reason: 'Shoulder impingement' },
      { t: 4, pat: 'pat-sofia', st: 'waiting', dur: 0, reason: 'Wrist pain evaluation' },
      { t: 5, pat: 'pat-ava', st: 'waiting', dur: 0, reason: 'Running injury assessment' },
    ];
    for (const item of kowalskiSeed) {
      const apptId = `appt-kowalski-${item.t}`;
      const isDone = item.st === 'completed';
      const isActive = item.st === 'in_consultation';
      insertAppt.run(
        apptId,
        'sess-doc-kowalski-today-am',
        item.pat,
        item.t,
        item.t * 10,
        item.st,
        0,
        null,
        item.reason,
        item.t <= 3 ? minutesAgoIso(45 - item.t * 5) : null,
        item.t <= 3 ? 'manual' : null,
        isDone || isActive ? minutesAgoIso(30 - item.t * 5) : null,
        isDone || isActive ? minutesAgoIso(29 - item.t * 5) : null,
        isDone ? minutesAgoIso(15 - item.t * 5) : null,
        minutesAgoIso(120),
        minutesAgoIso(6)
      );
      if (isDone) {
        insertDuration.run('doc-kowalski', 'sess-doc-kowalski-today-am', apptId, item.dur, minutesAgoIso(15 - item.t * 5));
      }
    }

    // 5) Dr. Sofia Alvarez (Cardiology, Harborview) — Tokens #1..#4
    const alvarezSeed = [
      { t: 1, pat: 'pat-noah', st: 'completed', dur: 13, reason: 'Lipid panel review' },
      { t: 2, pat: 'pat-ava', st: 'called', dur: 0, reason: 'Palpitation evaluation' },
      { t: 3, pat: 'pat-david', st: 'waiting', dur: 0, reason: 'Annual echocardiogram review' },
      { t: 4, pat: 'pat-maya', st: 'waiting', dur: 0, reason: 'Blood pressure follow-up' },
    ];
    for (const item of alvarezSeed) {
      const apptId = `appt-alvarez-${item.t}`;
      const isDone = item.st === 'completed';
      const isCalled = item.st === 'called';
      insertAppt.run(
        apptId,
        'sess-doc-alvarez-today-am',
        item.pat,
        item.t,
        item.t * 10,
        item.st,
        0,
        null,
        item.reason,
        item.t <= 2 ? minutesAgoIso(30 - item.t * 5) : null,
        item.t <= 2 ? 'manual' : null,
        isDone || isCalled ? minutesAgoIso(20 - item.t * 5) : null,
        isDone ? minutesAgoIso(19) : null,
        isDone ? minutesAgoIso(6) : null,
        minutesAgoIso(100),
        minutesAgoIso(4)
      );
      if (isDone) {
        insertDuration.run('doc-alvarez', 'sess-doc-alvarez-today-am', apptId, item.dur, minutesAgoIso(6));
      }
    }

    // 6) Evening upcoming appointment for Aarav Patel (Dr. Mehta Today Evening)
    insertAppt.run(
      'appt-mehta-pm-1',
      'sess-doc-mehta-today-pm',
      'pat-noah',
      1,
      10,
      'waiting',
      0,
      null,
      'Routine cardiac review',
      null,
      null,
      null,
      null,
      null,
      minutesAgoIso(90),
      minutesAgoIso(90)
    );

    // Seed baseline consultation durations for remaining doctors so EWMA is populated
    const extraDurations: Array<[string, string, number]> = [
      ['doc-okafor', 'sess-doc-okafor-today-am', 11],
      ['doc-okafor', 'sess-doc-okafor-today-am', 12],
      ['doc-nair', 'sess-doc-nair-today-am', 15],
      ['doc-nair', 'sess-doc-nair-today-am', 14],
      ['doc-bennett', 'sess-doc-bennett-today-am', 11],
      ['doc-bennett', 'sess-doc-bennett-today-am', 10],
    ];
    for (const [docId, sessId, dur] of extraDurations) {
      insertDuration.run(docId, sessId, null, dur, minutesAgoIso(120));
    }

    // Seed prescription / visit note for Aarav Patel's completed appointment with Dr. Chen
    db.prepare(`
      INSERT INTO visit_notes (id, appointment_id, doctor_id, patient_id, diagnosis, medications, instructions, follow_up, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'note-chen-1',
      'appt-chen-1',
      'doc-chen',
      'pat-aarav',
      'Mild Vitamin D insufficiency & seasonal fatigue',
      'Cholecalciferol (Vitamin D3) 2000 IU once daily with breakfast for 8 weeks',
      'Maintain regular hydration, aim for 20 minutes of morning sunlight daily, and avoid taking supplement on an empty stomach.',
      'Repeat serum 25(OH)D lab panel in 8 weeks',
      minutesAgoIso(25)
    );

    // Seed initial notifications for Aarav Patel (Token #6 with Dr. Rivera is 2 positions away!)
    db.prepare(`
      INSERT INTO notifications (id, patient_id, appointment_id, type, channel, title, message, is_read, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'notif-seed-1',
      'pat-aarav',
      'appt-rivera-6',
      'two_away',
      'Simulated SMS & Push',
      'Almost your turn — 2 positions away',
      'Token #6 with Dr. Elena Rivera (Westside Family & Pediatric Center) is now 2 positions away. Estimated wait: ~29 min.',
      0,
      minutesAgoIso(4)
    );

    // Seed audit log entries
    const insertAudit = db.prepare(`
      INSERT INTO queue_audit_logs (id, session_id, appointment_id, actor_role, actor_name, action, details, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    insertAudit.run(
      'audit-seed-1',
      'sess-doc-mehta-today-am',
      'appt-mehta-10',
      'doctor',
      'Dr. Priya Mehta',
      'MARK_ABSENT',
      'Token #10 marked absent/skipped after no response at Suite 204.',
      minutesAgoIso(12)
    );
    insertAudit.run(
      'audit-seed-2',
      'sess-doc-mehta-today-am',
      'appt-mehta-11',
      'doctor',
      'Dr. Priya Mehta',
      'CALL_NEXT',
      'Token #11 called and consultation started at Suite 204.',
      minutesAgoIso(6)
    );
    insertAudit.run(
      'audit-seed-3',
      'sess-doc-kowalski-today-am',
      null,
      'doctor',
      'Dr. Viktor Kowalski',
      'DELAY_REPORTED',
      'Reported +10 minute session delay due to imaging review.',
      minutesAgoIso(18)
    );
    insertAudit.run(
      'audit-seed-4',
      'sess-doc-okafor-today-am',
      null,
      'doctor',
      'Dr. Samuel Okafor',
      'STATUS_ON_BREAK',
      'Doctor stepped away for scheduled 10-minute mid-morning break.',
      minutesAgoIso(7)
    );
  });

  tx();
}
