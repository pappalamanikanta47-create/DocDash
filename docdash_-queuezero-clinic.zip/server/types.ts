export type Role = 'patient' | 'doctor' | 'staff';

export type Specialty =
  | 'General Medicine'
  | 'Pediatrics'
  | 'Orthopedics'
  | 'Cardiology';

export type SessionPeriod = 'morning' | 'evening';

export type DoctorSessionStatus = 'in_consultation' | 'on_break' | 'delayed';

export type AppointmentStatus =
  | 'waiting'
  | 'checked_in'
  | 'called'
  | 'in_consultation'
  | 'completed'
  | 'skipped'
  | 'cancelled';

export interface ClinicRow {
  id: string;
  name: string;
  branch_code: string;
  address: string;
  district: string;
  phone: string;
  latitude: number;
  longitude: number;
  image_url: string;
  opening_hours: string;
}

export interface DoctorRow {
  id: string;
  clinic_id: string;
  name: string;
  specialty: Specialty;
  qualifications: string;
  room_number: string;
  consultation_fee: number;
  historical_avg_minutes: number;
  bio: string;
}

export interface SessionRow {
  id: string;
  doctor_id: string;
  clinic_id: string;
  session_date: string;
  period: SessionPeriod;
  start_time: string;
  end_time: string;
  status: DoctorSessionStatus;
  delay_minutes: number;
  break_minutes: number;
  is_active: number;
  updated_at: string;
}

export interface PatientRow {
  id: string;
  full_name: string;
  phone: string;
  created_at: string;
}

export interface AppointmentRow {
  id: string;
  session_id: string;
  patient_id: string;
  token_number: number;
  queue_order: number;
  status: AppointmentStatus;
  is_urgent: number;
  urgent_reason: string | null;
  reason: string | null;
  checked_in_at: string | null;
  checkin_method: string | null;
  called_at: string | null;
  started_at: string | null;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface VisitNoteRow {
  id: string;
  appointment_id: string;
  doctor_id: string;
  patient_id: string;
  diagnosis: string;
  medications: string;
  instructions: string;
  follow_up: string | null;
  created_at: string;
}

export interface NotificationRow {
  id: string;
  patient_id: string;
  appointment_id: string;
  type: string;
  channel: string;
  title: string;
  message: string;
  is_read: number;
  created_at: string;
}

export interface AuditLogRow {
  id: string;
  session_id: string;
  appointment_id: string | null;
  actor_role: string;
  actor_name: string;
  action: string;
  details: string;
  created_at: string;
}
