import type Database from 'better-sqlite3';
import express from 'express';
import {
  computeDoctorEwma,
  computeSessionQueueState,
  evaluateAndTriggerAlerts,
  haversineMeters,
  makeId,
  normalizePhone,
} from './queueEngine.ts';
import type {
  AppointmentRow,
  AuditLogRow,
  ClinicRow,
  DoctorRow,
  DoctorSessionStatus,
  NotificationRow,
  PatientRow,
  SessionRow,
  VisitNoteRow,
} from './types.ts';

export type BroadcastFn = (event: {
  type: string;
  sessionId?: string;
  clinicId?: string;
  doctorId?: string;
  timestamp: string;
}) => void;

export function createApiRouter(
  db: Database.Database,
  broadcast: BroadcastFn
): express.Router {
  const router = express.Router();

  function emitUpdate(
    type: string,
    meta?: { sessionId?: string; clinicId?: string; doctorId?: string }
  ) {
    broadcast({
      type,
      ...meta,
      timestamp: new Date().toISOString(),
    });
  }

  // Health check
  router.get('/health', (_req, res) => {
    res.json({ ok: true, timestamp: new Date().toISOString() });
  });

  // 1. Clinics directory
  router.get('/clinics', (_req, res) => {
    const clinics = db.prepare('SELECT * FROM clinics ORDER BY name ASC').all() as ClinicRow[];
    const doctors = db.prepare('SELECT id, clinic_id, specialty FROM doctors').all() as Array<{
      id: string;
      clinic_id: string;
      specialty: string;
    }>;
    const sessions = db
      .prepare('SELECT id, clinic_id FROM clinic_sessions WHERE is_active = 1')
      .all() as Array<{ id: string; clinic_id: string }>;

    const enriched = clinics.map((clinic) => {
      const clinicDocs = doctors.filter((d) => d.clinic_id === clinic.id);
      const clinicSessions = sessions.filter((s) => s.clinic_id === clinic.id);
      let activeWaiting = 0;
      for (const s of clinicSessions) {
        const q = computeSessionQueueState(db, s.id);
        if (q && s.id.includes('today-am')) {
          activeWaiting += q.waitingCount;
        }
      }
      return {
        ...clinic,
        doctorCount: clinicDocs.length,
        specialties: Array.from(new Set(clinicDocs.map((d) => d.specialty))),
        activeWaiting,
      };
    });

    res.json({ clinics: enriched });
  });

  // 2. Doctors directory with session summaries (no patient PII)
  router.get('/doctors', (req, res) => {
    const clinicId = typeof req.query.clinicId === 'string' ? req.query.clinicId : '';
    const specialty = typeof req.query.specialty === 'string' ? req.query.specialty : '';
    const q = typeof req.query.q === 'string' ? req.query.q.trim().toLowerCase() : '';

    const doctors = db.prepare('SELECT * FROM doctors ORDER BY name ASC').all() as DoctorRow[];
    const clinics = db.prepare('SELECT * FROM clinics').all() as ClinicRow[];
    const clinicMap = new Map(clinics.map((c) => [c.id, c]));

    const result = doctors
      .filter((doc) => {
        if (clinicId && clinicId !== 'all' && doc.clinic_id !== clinicId) return false;
        if (specialty && specialty !== 'all' && doc.specialty !== specialty) return false;
        if (q) {
          const clinic = clinicMap.get(doc.clinic_id);
          const hay = `${doc.name} ${doc.specialty} ${clinic?.name ?? ''}`.toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      })
      .map((doc) => {
        const clinic = clinicMap.get(doc.clinic_id)!;
        const sessions = db
          .prepare(
            `SELECT * FROM clinic_sessions
             WHERE doctor_id = ? AND is_active = 1
             ORDER BY session_date ASC, CASE period WHEN 'morning' THEN 0 ELSE 1 END ASC`
          )
          .all(doc.id) as SessionRow[];

        const ewmaMinutes = computeDoctorEwma(db, doc.id, doc.historical_avg_minutes);
        const sessionSummaries = sessions.map((sess) => {
          const state = computeSessionQueueState(db, sess.id)!;
          return {
            id: sess.id,
            session_date: sess.session_date,
            period: sess.period,
            start_time: sess.start_time,
            end_time: sess.end_time,
            status: sess.status,
            delay_minutes: sess.delay_minutes,
            break_minutes: sess.break_minutes,
            currentTokenNumber: state.currentTokenNumber,
            waitingCount: state.waitingCount,
            nextTokenNumber: state.nextTokenNumber,
            estimatedNewWaitMinutes: Math.max(
              0,
              Math.round(
                (state.waitingCount + (state.activeAppointment ? 1 : 0)) * ewmaMinutes +
                  sess.delay_minutes +
                  (sess.status === 'on_break' ? Math.max(10, sess.break_minutes || 10) : 0)
              )
            ),
            updated_at: sess.updated_at,
          };
        });

        return {
          ...doc,
          clinic,
          ewmaMinutes,
          activeSession: sessionSummaries[0] ?? null,
          sessions: sessionSummaries,
        };
      });

    res.json({ doctors: result });
  });

  // 3. Demo patient profiles (privacy-safe switcher for demo)
  router.get('/patients/demo', (_req, res) => {
    const patients = db
      .prepare(
        `SELECT p.id, p.full_name, p.phone,
          (SELECT COUNT(*) FROM appointments a WHERE a.patient_id = p.id) as appointmentCount
         FROM patients p
         WHERE p.id IN ('pat-aarav', 'pat-maya') OR p.id LIKE 'pat-%'
         ORDER BY CASE WHEN p.id = 'pat-aarav' THEN 0 WHEN p.id = 'pat-maya' THEN 1 ELSE 2 END, p.created_at DESC
         LIMIT 8`
      )
      .all() as Array<{
      id: string;
      full_name: string;
      phone: string;
      appointmentCount: number;
    }>;

    res.json({
      patients: patients.map((p) => ({
        id: p.id,
        full_name: p.full_name,
        maskedPhone: `•••-•••-${p.phone.slice(-4)}`,
        phone: p.phone,
        appointmentCount: p.appointmentCount,
      })),
    });
  });

  // 4. Patient's own appointments & live queue tracking (scoped strictly to patientId or phone)
  router.get('/appointments/my', (req, res) => {
    const patientIdParam = typeof req.query.patientId === 'string' ? req.query.patientId.trim() : '';
    const phoneParam = typeof req.query.phone === 'string' ? normalizePhone(req.query.phone) : '';

    if (!patientIdParam && !phoneParam) {
      res.status(400).json({ error: 'Patient identifier is required.' });
      return;
    }

    const patient = (
      patientIdParam
        ? db.prepare('SELECT * FROM patients WHERE id = ?').get(patientIdParam)
        : db.prepare('SELECT * FROM patients WHERE phone = ?').get(phoneParam)
    ) as PatientRow | undefined;

    if (!patient) {
      res.json({ patient: null, appointments: [], notifications: [] });
      return;
    }

    const appts = db
      .prepare(
        `SELECT * FROM appointments
         WHERE patient_id = ?
         ORDER BY created_at DESC`
      )
      .all(patient.id) as AppointmentRow[];

    const enriched = appts.map((appt) => {
      const summary = computeSessionQueueState(db, appt.session_id);
      const computed = summary?.computedMap.get(appt.id);
      const note = db
        .prepare('SELECT * FROM visit_notes WHERE appointment_id = ?')
        .get(appt.id) as VisitNoteRow | undefined;

      return {
        ...appt,
        session: summary?.session ?? null,
        doctor: summary?.doctor ?? null,
        clinic: summary?.clinic ?? null,
        currentTokenNumber: summary?.currentTokenNumber ?? null,
        ewmaMinutes: summary?.ewmaMinutes ?? null,
        queuePosition: computed?.queuePosition ?? null,
        patientsAhead: computed?.patientsAhead ?? 0,
        estimatedWaitMinutes: computed?.estimatedWaitMinutes ?? null,
        lastUpdated: summary?.session.updated_at ?? appt.updated_at,
        visitNote: note ?? null,
      };
    });

    const notifications = db
      .prepare(
        `SELECT * FROM notifications
         WHERE patient_id = ?
         ORDER BY created_at DESC
         LIMIT 25`
      )
      .all(patient.id) as NotificationRow[];

    res.json({
      patient: {
        id: patient.id,
        full_name: patient.full_name,
        phone: patient.phone,
      },
      appointments: enriched,
      notifications,
    });
  });

  // 5. Book a new appointment token
  router.post('/appointments', (req, res) => {
    const { sessionId, patientName, patientPhone, reason } = req.body ?? {};

    if (typeof sessionId !== 'string' || !sessionId.trim()) {
      res.status(400).json({ error: 'Please select a valid clinic session.' });
      return;
    }
    if (typeof patientName !== 'string' || patientName.trim().length < 2) {
      res.status(400).json({ error: 'Please enter the patient’s full name (at least 2 characters).' });
      return;
    }
    const cleanPhone = typeof patientPhone === 'string' ? normalizePhone(patientPhone) : '';
    if (cleanPhone.length < 7) {
      res.status(400).json({ error: 'Please enter a valid contact phone number (at least 7 digits).' });
      return;
    }

    const session = db
      .prepare('SELECT * FROM clinic_sessions WHERE id = ? AND is_active = 1')
      .get(sessionId) as SessionRow | undefined;

    if (!session) {
      res.status(404).json({ error: 'Selected clinic session is unavailable.' });
      return;
    }

    const cleanName = patientName.trim();
    const cleanReason = typeof reason === 'string' ? reason.trim().slice(0, 240) : '';
    const now = new Date().toISOString();

    try {
      const created = db.transaction(() => {
        let patient = db
          .prepare('SELECT * FROM patients WHERE phone = ?')
          .get(cleanPhone) as PatientRow | undefined;

        if (!patient) {
          const newPatId = makeId('pat');
          db.prepare(
            'INSERT INTO patients (id, full_name, phone, created_at) VALUES (?, ?, ?, ?)'
          ).run(newPatId, cleanName, cleanPhone, now);
          patient = db.prepare('SELECT * FROM patients WHERE id = ?').get(newPatId) as PatientRow;
        } else if (patient.full_name !== cleanName && cleanName.length >= 2) {
          db.prepare('UPDATE patients SET full_name = ? WHERE id = ?').run(cleanName, patient.id);
          patient.full_name = cleanName;
        }

        const existing = db
          .prepare(
            `SELECT id, token_number FROM appointments
             WHERE session_id = ? AND patient_id = ?
               AND status IN ('waiting', 'checked_in', 'called', 'in_consultation')`
          )
          .get(session.id, patient.id) as { id: string; token_number: number } | undefined;

        if (existing) {
          const err = new Error(
            `You already hold active Token #${existing.token_number} for this clinic session.`
          ) as Error & { statusCode?: number };
          err.statusCode = 409;
          throw err;
        }

        const maxRow = db
          .prepare(
            `SELECT COALESCE(MAX(token_number), 0) as maxToken,
                    COALESCE(MAX(queue_order), 0) as maxOrder
             FROM appointments WHERE session_id = ?`
          )
          .get(session.id) as { maxToken: number; maxOrder: number };

        const nextToken = maxRow.maxToken + 1;
        const nextOrder = Math.max(nextToken * 10, maxRow.maxOrder + 10);
        const apptId = makeId('appt');

        db.prepare(
          `INSERT INTO appointments (
            id, session_id, patient_id, token_number, queue_order, status,
            is_urgent, urgent_reason, reason, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, 'waiting', 0, NULL, ?, ?, ?)`
        ).run(apptId, session.id, patient.id, nextToken, nextOrder, cleanReason || null, now, now);

        db.prepare('UPDATE clinic_sessions SET updated_at = ? WHERE id = ?').run(now, session.id);

        db.prepare(
          `INSERT INTO queue_audit_logs (id, session_id, appointment_id, actor_role, actor_name, action, details, created_at)
           VALUES (?, ?, ?, 'patient', ?, 'BOOK_TOKEN', ?, ?)`
        ).run(
          makeId('audit'),
          session.id,
          apptId,
          patient.full_name,
          `Booked Token #${nextToken} (${session.period} session on ${session.session_date}).`,
          now
        );

        evaluateAndTriggerAlerts(db, session.id);
        return { apptId, patient };
      })();

      const summary = computeSessionQueueState(db, session.id)!;
      const computed = summary.computedMap.get(created.apptId)!;

      emitUpdate('queue:updated', {
        sessionId: session.id,
        clinicId: session.clinic_id,
        doctorId: session.doctor_id,
      });

      res.status(201).json({
        patient: created.patient,
        appointment: {
          ...computed.appointment,
          session: summary.session,
          doctor: summary.doctor,
          clinic: summary.clinic,
          currentTokenNumber: summary.currentTokenNumber,
          ewmaMinutes: summary.ewmaMinutes,
          queuePosition: computed.queuePosition,
          patientsAhead: computed.patientsAhead,
          estimatedWaitMinutes: computed.estimatedWaitMinutes,
          lastUpdated: summary.session.updated_at,
        },
      });
    } catch (err) {
      const status = (err as { statusCode?: number }).statusCode || 500;
      res.status(status).json({ error: (err as Error).message || 'Booking failed.' });
    }
  });

  // 6. Patient or Staff Check-In (optional geolocation within 500m OR manual check-in)
  router.post('/appointments/:id/checkin', (req, res) => {
    const apptId = req.params.id;
    const { mode, latitude, longitude, patientId, actorRole } = req.body ?? {};

    const appt = db.prepare('SELECT * FROM appointments WHERE id = ?').get(apptId) as
      | AppointmentRow
      | undefined;

    if (!appt) {
      res.status(404).json({ error: 'Appointment not found.' });
      return;
    }

    if (actorRole !== 'staff' && patientId && appt.patient_id !== patientId) {
      res.status(403).json({ error: 'Not authorized to check in this appointment.' });
      return;
    }

    if (appt.status !== 'waiting' && appt.status !== 'checked_in') {
      res.status(400).json({ error: `Cannot check in an appointment with status "${appt.status}".` });
      return;
    }

    const session = db
      .prepare('SELECT * FROM clinic_sessions WHERE id = ?')
      .get(appt.session_id) as SessionRow;
    const clinic = db
      .prepare('SELECT * FROM clinics WHERE id = ?')
      .get(session.clinic_id) as ClinicRow;

    let method = 'manual';
    let distanceMeters: number | null = null;

    if (mode === 'geolocation') {
      if (typeof latitude !== 'number' || typeof longitude !== 'number') {
        res.status(400).json({ error: 'Location coordinates are required for proximity check-in.' });
        return;
      }
      distanceMeters = haversineMeters(latitude, longitude, clinic.latitude, clinic.longitude);
      if (distanceMeters > 500) {
        res.status(400).json({
          error: `You appear to be ${distanceMeters}m away from ${clinic.name} (check-in radius is 500m). Please use Manual Check-In at the front desk or when closer.`,
          distanceMeters,
        });
        return;
      }
      method = 'geolocation';
    }

    const now = new Date().toISOString();
    db.transaction(() => {
      db.prepare(
        `UPDATE appointments
         SET status = 'checked_in', checked_in_at = ?, checkin_method = ?, updated_at = ?
         WHERE id = ?`
      ).run(now, method, now, appt.id);

      db.prepare('UPDATE clinic_sessions SET updated_at = ? WHERE id = ?').run(now, session.id);

      db.prepare(
        `INSERT INTO queue_audit_logs (id, session_id, appointment_id, actor_role, actor_name, action, details, created_at)
         VALUES (?, ?, ?, ?, ?, 'CHECK_IN', ?, ?)`
      ).run(
        makeId('audit'),
        session.id,
        appt.id,
        actorRole === 'staff' ? 'staff' : 'patient',
        actorRole === 'staff' ? 'Clinic Front Desk' : 'Patient App',
        `Token #${appt.token_number} checked in via ${method}${distanceMeters !== null ? ` (${distanceMeters}m from branch)` : ''}.`,
        now
      );
    })();

    emitUpdate('queue:updated', {
      sessionId: session.id,
      clinicId: session.clinic_id,
      doctorId: session.doctor_id,
    });

    res.json({ ok: true, method, distanceMeters, checkedInAt: now });
  });

  // 7. Patient cancels own waiting appointment
  router.post('/appointments/:id/cancel', (req, res) => {
    const apptId = req.params.id;
    const { patientId } = req.body ?? {};
    const appt = db.prepare('SELECT * FROM appointments WHERE id = ?').get(apptId) as
      | AppointmentRow
      | undefined;

    if (!appt) {
      res.status(404).json({ error: 'Appointment not found.' });
      return;
    }
    if (patientId && appt.patient_id !== patientId) {
      res.status(403).json({ error: 'Not authorized to cancel this appointment.' });
      return;
    }
    if (appt.status !== 'waiting' && appt.status !== 'checked_in') {
      res.status(400).json({ error: 'Only waiting or checked-in tokens can be cancelled.' });
      return;
    }

    const now = new Date().toISOString();
    const session = db
      .prepare('SELECT * FROM clinic_sessions WHERE id = ?')
      .get(appt.session_id) as SessionRow;

    db.transaction(() => {
      db.prepare(`UPDATE appointments SET status = 'cancelled', updated_at = ? WHERE id = ?`).run(
        now,
        appt.id
      );
      db.prepare('UPDATE clinic_sessions SET updated_at = ? WHERE id = ?').run(now, appt.session_id);
      db.prepare(
        `INSERT INTO queue_audit_logs (id, session_id, appointment_id, actor_role, actor_name, action, details, created_at)
         VALUES (?, ?, ?, 'patient', 'Patient', 'CANCEL_TOKEN', ?, ?)`
      ).run(
        makeId('audit'),
        appt.session_id,
        appt.id,
        `Token #${appt.token_number} cancelled by patient.`,
        now
      );
      evaluateAndTriggerAlerts(db, appt.session_id);
    })();

    emitUpdate('queue:updated', {
      sessionId: session.id,
      clinicId: session.clinic_id,
      doctorId: session.doctor_id,
    });

    res.json({ ok: true });
  });

  // 8. Mark patient notifications read
  router.post('/notifications/read', (req, res) => {
    const { patientId } = req.body ?? {};
    if (typeof patientId !== 'string' || !patientId) {
      res.status(400).json({ error: 'patientId is required.' });
      return;
    }
    db.prepare('UPDATE notifications SET is_read = 1 WHERE patient_id = ?').run(patientId);
    res.json({ ok: true });
  });

  // 9. Doctor console data
  router.get('/doctor/sessions', (req, res) => {
    const doctorId = typeof req.query.doctorId === 'string' && req.query.doctorId ? req.query.doctorId : 'doc-mehta';
    const sessionIdParam = typeof req.query.sessionId === 'string' ? req.query.sessionId : '';

    const doctors = db
      .prepare(
        `SELECT d.*, c.name as clinic_name, c.branch_code
         FROM doctors d JOIN clinics c ON d.clinic_id = c.id
         ORDER BY CASE WHEN d.id = 'doc-mehta' THEN 0 ELSE 1 END, d.name ASC`
      )
      .all();

    const doctorSessions = db
      .prepare(
        `SELECT * FROM clinic_sessions
         WHERE doctor_id = ? AND is_active = 1
         ORDER BY session_date ASC, CASE period WHEN 'morning' THEN 0 ELSE 1 END ASC`
      )
      .all(doctorId) as SessionRow[];

    const selectedSession =
      doctorSessions.find((s) => s.id === sessionIdParam) ?? doctorSessions[0] ?? null;

    if (!selectedSession) {
      res.json({ doctors, sessions: [], activeQueue: null });
      return;
    }

    const summary = computeSessionQueueState(db, selectedSession.id)!;
    const allAppts = db
      .prepare('SELECT * FROM appointments WHERE session_id = ? ORDER BY token_number ASC')
      .all(selectedSession.id) as AppointmentRow[];

    const patients = db
      .prepare(
        `SELECT p.* FROM patients p
         WHERE p.id IN (SELECT patient_id FROM appointments WHERE session_id = ?)`
      )
      .all(selectedSession.id) as PatientRow[];
    const patientMap = new Map(patients.map((p) => [p.id, p]));

    const notes = db
      .prepare(
        `SELECT * FROM visit_notes
         WHERE appointment_id IN (SELECT id FROM appointments WHERE session_id = ?)`
      )
      .all(selectedSession.id) as VisitNoteRow[];
    const noteMap = new Map(notes.map((n) => [n.appointment_id, n]));

    const hydrateAppt = (a: AppointmentRow) => {
      const comp = summary.computedMap.get(a.id);
      const pat = patientMap.get(a.patient_id);
      return {
        ...a,
        patientName: pat?.full_name ?? 'Patient',
        patientPhoneMasked: pat ? `•••-•••-${pat.phone.slice(-4)}` : '',
        queuePosition: comp?.queuePosition ?? null,
        patientsAhead: comp?.patientsAhead ?? 0,
        estimatedWaitMinutes: comp?.estimatedWaitMinutes ?? null,
        visitNote: noteMap.get(a.id) ?? null,
      };
    };

    const recentDurations = db
      .prepare(
        `SELECT duration_minutes, created_at FROM consultation_durations
         WHERE doctor_id = ? ORDER BY created_at DESC, id DESC LIMIT 8`
      )
      .all(doctorId);

    const auditLogs = db
      .prepare(
        `SELECT * FROM queue_audit_logs
         WHERE session_id = ? ORDER BY created_at DESC LIMIT 20`
      )
      .all(selectedSession.id) as AuditLogRow[];

    res.json({
      doctors,
      sessions: doctorSessions,
      activeQueue: {
        session: summary.session,
        doctor: summary.doctor,
        clinic: summary.clinic,
        ewmaMinutes: summary.ewmaMinutes,
        currentTokenNumber: summary.currentTokenNumber,
        activeAppointment: summary.activeAppointment
          ? hydrateAppt(summary.activeAppointment)
          : null,
        waitingList: summary.orderedWaiting.map(hydrateAppt),
        completedList: allAppts
          .filter((a) => a.status === 'completed')
          .sort((a, b) => b.token_number - a.token_number)
          .map(hydrateAppt),
        skippedList: allAppts
          .filter((a) => a.status === 'skipped')
          .sort((a, b) => a.token_number - b.token_number)
          .map(hydrateAppt),
        recentDurations,
        auditLogs,
      },
    });
  });

  // 10. Doctor: Call Next Patient
  router.post('/doctor/sessions/:sessionId/call-next', (req, res) => {
    const { sessionId } = req.params;
    const { completeCurrent } = req.body ?? {};

    const summary = computeSessionQueueState(db, sessionId);
    if (!summary) {
      res.status(404).json({ error: 'Clinic session not found.' });
      return;
    }

    if (summary.orderedWaiting.length === 0) {
      res.status(400).json({ error: 'No waiting patients remaining in this session.' });
      return;
    }

    if (summary.activeAppointment && !completeCurrent) {
      res.status(409).json({
        error: `Token #${summary.activeAppointment.token_number} is currently active. Complete or skip the current patient first, or confirm completing and calling next.`,
        requiresCompletion: true,
        activeTokenNumber: summary.activeAppointment.token_number,
      });
      return;
    }

    const now = new Date().toISOString();
    const nextPatient = summary.orderedWaiting[0];

    db.transaction(() => {
      if (summary.activeAppointment && completeCurrent) {
        const started = summary.activeAppointment.started_at || summary.activeAppointment.called_at;
        let durationMin = summary.ewmaMinutes;
        if (started) {
          const diff = (Date.now() - new Date(started).getTime()) / 60_000;
          durationMin = Math.min(45, Math.max(5, Math.round(diff * 10) / 10));
        }
        db.prepare(
          `UPDATE appointments
           SET status = 'completed', completed_at = ?, updated_at = ?
           WHERE id = ?`
        ).run(now, now, summary.activeAppointment.id);

        db.prepare(
          `INSERT INTO consultation_durations (doctor_id, session_id, appointment_id, duration_minutes, created_at)
           VALUES (?, ?, ?, ?, ?)`
        ).run(
          summary.doctor.id,
          sessionId,
          summary.activeAppointment.id,
          durationMin,
          now
        );

        db.prepare(
          `INSERT INTO queue_audit_logs (id, session_id, appointment_id, actor_role, actor_name, action, details, created_at)
           VALUES (?, ?, ?, 'doctor', ?, 'COMPLETE_CONSULTATION', ?, ?)`
        ).run(
          makeId('audit'),
          sessionId,
          summary.activeAppointment.id,
          summary.doctor.name,
          `Completed Token #${summary.activeAppointment.token_number} (${durationMin.toFixed(1)} min logged).`,
          now
        );
      }

      db.prepare(
        `UPDATE appointments
         SET status = 'in_consultation', called_at = COALESCE(called_at, ?), started_at = ?, updated_at = ?
         WHERE id = ?`
      ).run(now, now, now, nextPatient.id);

      db.prepare(
        `UPDATE clinic_sessions
         SET status = 'in_consultation', break_minutes = 0, updated_at = ?
         WHERE id = ?`
      ).run(now, sessionId);

      db.prepare(
        `INSERT INTO queue_audit_logs (id, session_id, appointment_id, actor_role, actor_name, action, details, created_at)
         VALUES (?, ?, ?, 'doctor', ?, 'CALL_NEXT', ?, ?)`
      ).run(
        makeId('audit'),
        sessionId,
        nextPatient.id,
        summary.doctor.name,
        `Called Token #${nextPatient.token_number} to ${summary.doctor.room_number}.`,
        now
      );

      // Trigger 'called' alert for newly called patient & 'two_away' for anyone now <=2 away
      db.prepare(
        `INSERT INTO notifications (id, patient_id, appointment_id, type, channel, title, message, is_read, created_at)
         VALUES (?, ?, ?, 'called', 'Simulated SMS & Push', 'Your token is now being served', ?, 0, ?)`
      ).run(
        makeId('notif'),
        nextPatient.patient_id,
        nextPatient.id,
        `Token #${nextPatient.token_number} with ${summary.doctor.name} is now called to ${summary.doctor.room_number} (${summary.clinic.name}).`,
        now
      );

      evaluateAndTriggerAlerts(db, sessionId);
    })();

    emitUpdate('queue:updated', {
      sessionId,
      clinicId: summary.clinic.id,
      doctorId: summary.doctor.id,
    });

    res.json({ ok: true, calledTokenNumber: nextPatient.token_number });
  });

  // 11. Doctor: Mark current consultation complete
  router.post('/doctor/appointments/:id/complete', (req, res) => {
    const appt = db.prepare('SELECT * FROM appointments WHERE id = ?').get(req.params.id) as
      | AppointmentRow
      | undefined;

    if (!appt) {
      res.status(404).json({ error: 'Appointment not found.' });
      return;
    }

    if (appt.status !== 'in_consultation' && appt.status !== 'called') {
      res.status(400).json({
        error: `Invalid transition: Token #${appt.token_number} is currently "${appt.status}". Only a called or active patient can be marked complete.`,
      });
      return;
    }

    const summary = computeSessionQueueState(db, appt.session_id)!;
    const now = new Date().toISOString();
    const { durationMinutes } = req.body ?? {};

    let recordedDuration = summary.ewmaMinutes;
    if (typeof durationMinutes === 'number' && durationMinutes >= 5 && durationMinutes <= 60) {
      recordedDuration = Math.round(durationMinutes * 10) / 10;
    } else if (appt.started_at || appt.called_at) {
      const refTime = new Date(appt.started_at || appt.called_at!).getTime();
      const diff = (Date.now() - refTime) / 60_000;
      recordedDuration = Math.min(45, Math.max(5, Math.round(diff * 10) / 10));
    }

    db.transaction(() => {
      db.prepare(
        `UPDATE appointments SET status = 'completed', completed_at = ?, updated_at = ? WHERE id = ?`
      ).run(now, now, appt.id);

      db.prepare(
        `INSERT INTO consultation_durations (doctor_id, session_id, appointment_id, duration_minutes, created_at)
         VALUES (?, ?, ?, ?, ?)`
      ).run(summary.doctor.id, appt.session_id, appt.id, recordedDuration, now);

      db.prepare('UPDATE clinic_sessions SET updated_at = ? WHERE id = ?').run(now, appt.session_id);

      db.prepare(
        `INSERT INTO queue_audit_logs (id, session_id, appointment_id, actor_role, actor_name, action, details, created_at)
         VALUES (?, ?, ?, 'doctor', ?, 'COMPLETE_CONSULTATION', ?, ?)`
      ).run(
        makeId('audit'),
        appt.session_id,
        appt.id,
        summary.doctor.name,
        `Completed Token #${appt.token_number} (${recordedDuration.toFixed(1)} min logged for EWMA).`,
        now
      );

      evaluateAndTriggerAlerts(db, appt.session_id);
    })();

    emitUpdate('queue:updated', {
      sessionId: appt.session_id,
      clinicId: summary.clinic.id,
      doctorId: summary.doctor.id,
    });

    res.json({ ok: true, recordedDuration });
  });

  // 12. Doctor: Mark patient absent / skip
  router.post('/doctor/appointments/:id/absent', (req, res) => {
    const appt = db.prepare('SELECT * FROM appointments WHERE id = ?').get(req.params.id) as
      | AppointmentRow
      | undefined;

    if (!appt) {
      res.status(404).json({ error: 'Appointment not found.' });
      return;
    }

    if (appt.status === 'completed' || appt.status === 'cancelled' || appt.status === 'skipped') {
      res.status(400).json({
        error: `Invalid transition: Token #${appt.token_number} is already "${appt.status}".`,
      });
      return;
    }

    const summary = computeSessionQueueState(db, appt.session_id)!;
    const now = new Date().toISOString();

    db.transaction(() => {
      db.prepare(
        `UPDATE appointments SET status = 'skipped', updated_at = ? WHERE id = ?`
      ).run(now, appt.id);

      db.prepare('UPDATE clinic_sessions SET updated_at = ? WHERE id = ?').run(now, appt.session_id);

      db.prepare(
        `INSERT INTO queue_audit_logs (id, session_id, appointment_id, actor_role, actor_name, action, details, created_at)
         VALUES (?, ?, ?, 'doctor', ?, 'MARK_ABSENT', ?, ?)`
      ).run(
        makeId('audit'),
        appt.session_id,
        appt.id,
        summary.doctor.name,
        `Token #${appt.token_number} marked absent/skipped; queue advanced automatically.`,
        now
      );

      db.prepare(
        `INSERT INTO notifications (id, patient_id, appointment_id, type, channel, title, message, is_read, created_at)
         VALUES (?, ?, ?, 'skipped', 'Simulated SMS & Push', 'Token skipped due to absence', ?, 0, ?)`
      ).run(
        makeId('notif'),
        appt.patient_id,
        appt.id,
        `Token #${appt.token_number} with ${summary.doctor.name} was marked absent/skipped. Please check with the front desk if you have arrived.`,
        now
      );

      evaluateAndTriggerAlerts(db, appt.session_id);
    })();

    emitUpdate('queue:updated', {
      sessionId: appt.session_id,
      clinicId: summary.clinic.id,
      doctorId: summary.doctor.id,
    });

    res.json({ ok: true });
  });

  // 13. Doctor/Staff: Recall a skipped patient back into waiting queue
  router.post('/doctor/appointments/:id/recall', (req, res) => {
    const appt = db.prepare('SELECT * FROM appointments WHERE id = ?').get(req.params.id) as
      | AppointmentRow
      | undefined;

    if (!appt) {
      res.status(404).json({ error: 'Appointment not found.' });
      return;
    }
    if (appt.status !== 'skipped') {
      res.status(400).json({ error: 'Only skipped/absent tokens can be recalled.' });
      return;
    }

    const summary = computeSessionQueueState(db, appt.session_id)!;
    const now = new Date().toISOString();
    const maxOrderRow = db
      .prepare('SELECT COALESCE(MAX(queue_order), 0) as maxOrder FROM appointments WHERE session_id = ?')
      .get(appt.session_id) as { maxOrder: number };

    db.transaction(() => {
      db.prepare(
        `UPDATE appointments
         SET status = 'checked_in', queue_order = ?, checked_in_at = COALESCE(checked_in_at, ?), updated_at = ?
         WHERE id = ?`
      ).run(maxOrderRow.maxOrder + 10, now, now, appt.id);

      db.prepare('UPDATE clinic_sessions SET updated_at = ? WHERE id = ?').run(now, appt.session_id);

      db.prepare(
        `INSERT INTO queue_audit_logs (id, session_id, appointment_id, actor_role, actor_name, action, details, created_at)
         VALUES (?, ?, ?, 'doctor', ?, 'RECALL_PATIENT', ?, ?)`
      ).run(
        makeId('audit'),
        appt.session_id,
        appt.id,
        summary.doctor.name,
        `Recalled previously skipped Token #${appt.token_number} into active queue.`,
        now
      );

      evaluateAndTriggerAlerts(db, appt.session_id);
    })();

    emitUpdate('queue:updated', {
      sessionId: appt.session_id,
      clinicId: summary.clinic.id,
      doctorId: summary.doctor.id,
    });

    res.json({ ok: true });
  });

  // 14. Doctor: Update session status / delay / break
  router.post('/doctor/sessions/:sessionId/status', (req, res) => {
    const { sessionId } = req.params;
    const { status, addDelayMinutes, resetDelay } = req.body ?? {};

    const session = db
      .prepare('SELECT * FROM clinic_sessions WHERE id = ?')
      .get(sessionId) as SessionRow | undefined;

    if (!session) {
      res.status(404).json({ error: 'Session not found.' });
      return;
    }

    const doctor = db
      .prepare('SELECT * FROM doctors WHERE id = ?')
      .get(session.doctor_id) as DoctorRow;

    const validStatuses: DoctorSessionStatus[] = ['in_consultation', 'on_break', 'delayed'];
    const nextStatus: DoctorSessionStatus = validStatuses.includes(status)
      ? status
      : session.status;

    let nextDelay = session.delay_minutes;
    if (resetDelay) {
      nextDelay = 0;
    } else if (typeof addDelayMinutes === 'number' && addDelayMinutes > 0) {
      nextDelay = Math.min(180, session.delay_minutes + addDelayMinutes);
    }

    const nextBreak = nextStatus === 'on_break' ? 10 : 0;
    const now = new Date().toISOString();

    db.transaction(() => {
      db.prepare(
        `UPDATE clinic_sessions
         SET status = ?, delay_minutes = ?, break_minutes = ?, updated_at = ?
         WHERE id = ?`
      ).run(nextStatus, nextDelay, nextBreak, now, sessionId);

      const actionLabel = addDelayMinutes
        ? `DELAY_+${addDelayMinutes}M`
        : `STATUS_${nextStatus.toUpperCase()}`;
      const details = addDelayMinutes
        ? `Added +${addDelayMinutes} min delay (total delay: ${nextDelay} min).`
        : resetDelay
        ? `Cleared session delay and set status to ${nextStatus.replace('_', ' ')}.`
        : `Updated doctor session status to ${nextStatus.replace('_', ' ')}.`;

      db.prepare(
        `INSERT INTO queue_audit_logs (id, session_id, appointment_id, actor_role, actor_name, action, details, created_at)
         VALUES (?, ?, NULL, 'doctor', ?, ?, ?, ?)`
      ).run(makeId('audit'), sessionId, doctor.name, actionLabel, details, now);
    })();

    emitUpdate('doctor:status_changed', {
      sessionId,
      clinicId: session.clinic_id,
      doctorId: session.doctor_id,
    });

    res.json({ ok: true, status: nextStatus, delay_minutes: nextDelay, break_minutes: nextBreak });
  });

  // 15. Doctor: Attach prescription / visit summary note
  router.post('/doctor/appointments/:id/note', (req, res) => {
    const appt = db.prepare('SELECT * FROM appointments WHERE id = ?').get(req.params.id) as
      | AppointmentRow
      | undefined;

    if (!appt) {
      res.status(404).json({ error: 'Appointment not found.' });
      return;
    }

    if (appt.status !== 'completed' && appt.status !== 'in_consultation') {
      res.status(400).json({
        error: 'Visit notes can only be attached to active or completed consultations.',
      });
      return;
    }

    const { diagnosis, medications, instructions, followUp } = req.body ?? {};
    if (typeof diagnosis !== 'string' || !diagnosis.trim()) {
      res.status(400).json({ error: 'Clinical diagnosis or summary is required.' });
      return;
    }

    const session = db
      .prepare('SELECT * FROM clinic_sessions WHERE id = ?')
      .get(appt.session_id) as SessionRow;

    const now = new Date().toISOString();
    const existing = db
      .prepare('SELECT id FROM visit_notes WHERE appointment_id = ?')
      .get(appt.id) as { id: string } | undefined;

    if (existing) {
      db.prepare(
        `UPDATE visit_notes
         SET diagnosis = ?, medications = ?, instructions = ?, follow_up = ?
         WHERE id = ?`
      ).run(
        diagnosis.trim(),
        typeof medications === 'string' ? medications.trim() : '',
        typeof instructions === 'string' ? instructions.trim() : '',
        typeof followUp === 'string' && followUp.trim() ? followUp.trim() : null,
        existing.id
      );
    } else {
      db.prepare(
        `INSERT INTO visit_notes (id, appointment_id, doctor_id, patient_id, diagnosis, medications, instructions, follow_up, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(
        makeId('note'),
        appt.id,
        session.doctor_id,
        appt.patient_id,
        diagnosis.trim(),
        typeof medications === 'string' ? medications.trim() : '',
        typeof instructions === 'string' ? instructions.trim() : '',
        typeof followUp === 'string' && followUp.trim() ? followUp.trim() : null,
        now
      );
    }

    emitUpdate('queue:updated', {
      sessionId: appt.session_id,
      clinicId: session.clinic_id,
      doctorId: session.doctor_id,
    });

    res.json({ ok: true });
  });

  // 16. Restricted access to prescription / visit note
  router.get('/appointments/:id/note', (req, res) => {
    const role = typeof req.query.role === 'string' ? req.query.role : 'patient';
    const patientId = typeof req.query.patientId === 'string' ? req.query.patientId : '';

    const appt = db.prepare('SELECT * FROM appointments WHERE id = ?').get(req.params.id) as
      | AppointmentRow
      | undefined;

    if (!appt) {
      res.status(404).json({ error: 'Appointment not found.' });
      return;
    }

    if (role !== 'doctor' && role !== 'staff' && appt.patient_id !== patientId) {
      res.status(403).json({
        error: 'Access denied. Visit summaries are restricted to the patient and authorized care team.',
      });
      return;
    }

    const note = db
      .prepare('SELECT * FROM visit_notes WHERE appointment_id = ?')
      .get(appt.id) as VisitNoteRow | undefined;

    if (!note) {
      res.status(404).json({ error: 'No visit summary attached yet.' });
      return;
    }

    res.json({ note });
  });

  // 17. Clinic Staff Overview
  router.get('/staff/overview', (req, res) => {
    const clinicIdFilter = typeof req.query.clinicId === 'string' ? req.query.clinicId : 'all';

    const clinics = db.prepare('SELECT * FROM clinics ORDER BY name ASC').all() as ClinicRow[];
    const sessions = db
      .prepare(
        `SELECT * FROM clinic_sessions
         WHERE is_active = 1 AND session_date = (SELECT MIN(session_date) FROM clinic_sessions WHERE is_active = 1)
         ORDER BY CASE period WHEN 'morning' THEN 0 ELSE 1 END ASC, id ASC`
      )
      .all() as SessionRow[];

    const sessionBoards = sessions
      .filter((s) => clinicIdFilter === 'all' || s.clinic_id === clinicIdFilter)
      .map((s) => {
        const state = computeSessionQueueState(db, s.id)!;
        const waitingPatients = state.orderedWaiting.map((appt) => {
          const pat = db
            .prepare('SELECT full_name, phone FROM patients WHERE id = ?')
            .get(appt.patient_id) as { full_name: string; phone: string } | undefined;
          const comp = state.computedMap.get(appt.id);
          return {
            ...appt,
            patientName: pat?.full_name ?? 'Patient',
            patientPhoneMasked: pat ? `•••-•••-${pat.phone.slice(-4)}` : '',
            patientsAhead: comp?.patientsAhead ?? 0,
            estimatedWaitMinutes: comp?.estimatedWaitMinutes ?? 0,
          };
        });

        return {
          session: state.session,
          doctor: state.doctor,
          clinic: state.clinic,
          ewmaMinutes: state.ewmaMinutes,
          currentTokenNumber: state.currentTokenNumber,
          waitingCount: state.waitingCount,
          completedCount: state.completedCount,
          skippedCount: state.skippedCount,
          waitingPatients,
        };
      });

    const auditLogs = db
      .prepare(
        `SELECT l.*, d.name as doctor_name, c.name as clinic_name
         FROM queue_audit_logs l
         JOIN clinic_sessions s ON l.session_id = s.id
         JOIN doctors d ON s.doctor_id = d.id
         JOIN clinics c ON s.clinic_id = c.id
         ORDER BY l.created_at DESC
         LIMIT 30`
      )
      .all();

    res.json({ clinics, sessionBoards, auditLogs });
  });

  // 18. Staff: Authorized Urgent-Patient Escalation
  router.post('/staff/sessions/:sessionId/escalate', (req, res) => {
    const { sessionId } = req.params;
    const { staffName, patientName, patientPhone, reason, confirmed } = req.body ?? {};

    if (!confirmed) {
      res.status(400).json({ error: 'Explicit staff confirmation is required for urgent escalation.' });
      return;
    }
    if (typeof reason !== 'string' || reason.trim().length < 5) {
      res.status(400).json({ error: 'Please provide an explicit escalation reason (at least 5 characters).' });
      return;
    }
    if (typeof patientName !== 'string' || patientName.trim().length < 2) {
      res.status(400).json({ error: 'Patient full name is required.' });
      return;
    }
    const cleanPhone = typeof patientPhone === 'string' ? normalizePhone(patientPhone) : '';
    if (cleanPhone.length < 7) {
      res.status(400).json({ error: 'Valid patient phone number is required.' });
      return;
    }

    const session = db
      .prepare('SELECT * FROM clinic_sessions WHERE id = ?')
      .get(sessionId) as SessionRow | undefined;

    if (!session) {
      res.status(404).json({ error: 'Clinic session not found.' });
      return;
    }

    const doctor = db
      .prepare('SELECT * FROM doctors WHERE id = ?')
      .get(session.doctor_id) as DoctorRow;
    const cleanStaff = typeof staffName === 'string' && staffName.trim() ? staffName.trim() : 'Front Desk Coordinator';
    const cleanReason = reason.trim().slice(0, 240);
    const now = new Date().toISOString();

    const result = db.transaction(() => {
      let patient = db.prepare('SELECT * FROM patients WHERE phone = ?').get(cleanPhone) as
        | PatientRow
        | undefined;

      if (!patient) {
        const newPatId = makeId('pat');
        db.prepare(
          'INSERT INTO patients (id, full_name, phone, created_at) VALUES (?, ?, ?, ?)'
        ).run(newPatId, patientName.trim(), cleanPhone, now);
        patient = db.prepare('SELECT * FROM patients WHERE id = ?').get(newPatId) as PatientRow;
      }

      const maxTokenRow = db
        .prepare('SELECT COALESCE(MAX(token_number), 0) as maxToken FROM appointments WHERE session_id = ?')
        .get(sessionId) as { maxToken: number };

      const minWaitingOrderRow = db
        .prepare(
          `SELECT COALESCE(MIN(queue_order), 10) as minOrder
           FROM appointments
           WHERE session_id = ? AND status IN ('waiting', 'checked_in') AND is_urgent = 0`
        )
        .get(sessionId) as { minOrder: number };

      const urgentOrder = minWaitingOrderRow.minOrder - 5;
      const nextToken = maxTokenRow.maxToken + 1;
      const apptId = makeId('appt');

      db.prepare(
        `INSERT INTO appointments (
          id, session_id, patient_id, token_number, queue_order, status,
          is_urgent, urgent_reason, reason, checked_in_at, checkin_method, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, 'checked_in', 1, ?, ?, ?, 'staff_desk', ?, ?)`
      ).run(
        apptId,
        sessionId,
        patient.id,
        nextToken,
        urgentOrder,
        cleanReason,
        `[Urgent Escalation] ${cleanReason}`,
        now,
        now,
        now
      );

      db.prepare('UPDATE clinic_sessions SET updated_at = ? WHERE id = ?').run(now, sessionId);

      db.prepare(
        `INSERT INTO queue_audit_logs (id, session_id, appointment_id, actor_role, actor_name, action, details, created_at)
         VALUES (?, ?, ?, 'staff', ?, 'URGENT_ESCALATION', ?, ?)`
      ).run(
        makeId('audit'),
        sessionId,
        apptId,
        cleanStaff,
        `Authorized urgent escalation for Token #${nextToken} (${doctor.name}). Reason: ${cleanReason}`,
        now
      );

      evaluateAndTriggerAlerts(db, sessionId);
      return { apptId, nextToken };
    })();

    emitUpdate('queue:updated', {
      sessionId,
      clinicId: session.clinic_id,
      doctorId: session.doctor_id,
    });

    res.status(201).json({ ok: true, tokenNumber: result.nextToken, appointmentId: result.apptId });
  });

  // 19. Historical wait-time heatmap guidance (clearly labeled as historical guidance)
  router.get('/analytics/wait-heatmap', (req, res) => {
    const clinicId = typeof req.query.clinicId === 'string' ? req.query.clinicId : 'clinic-metro';
    const clinics = db.prepare('SELECT id, name FROM clinics').all() as Array<{ id: string; name: string }>;
    const offset = clinics.findIndex((c) => c.id === clinicId);
    const shift = offset >= 0 ? offset * 3 : 0;

    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const slots = [
      { label: 'Morning (09:00–11:00)', base: 14 },
      { label: 'Midday (11:00–13:00)', base: 26 },
      { label: 'Evening (16:00–18:00)', base: 22 },
      { label: 'Late Eve (18:00–20:00)', base: 12 },
    ];

    const matrix = slots.map((slot, sIdx) => ({
      period: slot.label,
      values: days.map((day, dIdx) => {
        const dayFactor = dIdx === 0 ? 7 : dIdx === 5 ? 5 : dIdx === 2 ? -2 : dIdx;
        const avgMinutes = Math.max(8, slot.base + dayFactor + ((shift + sIdx * 2) % 6));
        return {
          day,
          avgMinutes,
          band: avgMinutes <= 16 ? 'low' : avgMinutes <= 25 ? 'moderate' : 'busy',
        };
      }),
    }));

    res.json({
      clinicId,
      disclaimer:
        'Historical 90-day outpatient averages for general planning only. Not a live wait prediction or guarantee.',
      days,
      matrix,
    });
  });

  return router;
}
