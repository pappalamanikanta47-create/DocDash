import type Database from 'better-sqlite3';
import crypto from 'crypto';
import type {
  AppointmentRow,
  ClinicRow,
  DoctorRow,
  SessionRow,
} from './types.ts';

export function makeId(prefix: string): string {
  return `${prefix}-${crypto.randomUUID().slice(0, 8)}`;
}

export function normalizePhone(raw: string): string {
  return raw.replace(/\D/g, '').slice(-10);
}

export function haversineMeters(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371000;
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

export function computeDoctorEwma(
  db: Database.Database,
  doctorId: string,
  historicalAvgFallback = 12
): number {
  const doctor = db
    .prepare('SELECT historical_avg_minutes FROM doctors WHERE id = ?')
    .get(doctorId) as { historical_avg_minutes: number } | undefined;

  let ewma = doctor?.historical_avg_minutes ?? historicalAvgFallback;

  const durations = db
    .prepare(
      `SELECT duration_minutes FROM consultation_durations
       WHERE doctor_id = ?
       ORDER BY created_at DESC, id DESC
       LIMIT 12`
    )
    .all(doctorId) as Array<{ duration_minutes: number }>;

  // Apply EWMA in chronological order (oldest -> newest)
  const chronological = [...durations].reverse();
  const alpha = 0.35;
  for (const row of chronological) {
    ewma = alpha * row.duration_minutes + (1 - alpha) * ewma;
  }

  return Math.max(5, Math.round(ewma * 10) / 10);
}

export interface ComputedAppointmentState {
  appointment: AppointmentRow;
  queuePosition: number | null;
  patientsAhead: number;
  estimatedWaitMinutes: number | null;
}

export interface SessionQueueSummary {
  session: SessionRow;
  doctor: DoctorRow;
  clinic: ClinicRow;
  ewmaMinutes: number;
  currentTokenNumber: number | null;
  activeAppointment: AppointmentRow | null;
  waitingCount: number;
  completedCount: number;
  skippedCount: number;
  nextTokenNumber: number;
  orderedWaiting: AppointmentRow[];
  computedMap: Map<string, ComputedAppointmentState>;
}

export function computeSessionQueueState(
  db: Database.Database,
  sessionId: string
): SessionQueueSummary | null {
  const session = db
    .prepare('SELECT * FROM clinic_sessions WHERE id = ?')
    .get(sessionId) as SessionRow | undefined;

  if (!session) return null;

  const doctor = db
    .prepare('SELECT * FROM doctors WHERE id = ?')
    .get(session.doctor_id) as DoctorRow;
  const clinic = db
    .prepare('SELECT * FROM clinics WHERE id = ?')
    .get(session.clinic_id) as ClinicRow;

  const appointments = db
    .prepare('SELECT * FROM appointments WHERE session_id = ?')
    .all(sessionId) as AppointmentRow[];

  const ewmaMinutes = computeDoctorEwma(db, doctor.id, doctor.historical_avg_minutes);

  const activeCandidates = appointments
    .filter((a) => a.status === 'in_consultation' || a.status === 'called')
    .sort((a, b) => a.queue_order - b.queue_order || a.token_number - b.token_number);

  const activeAppointment = activeCandidates[0] ?? null;

  const orderedWaiting = appointments
    .filter((a) => a.status === 'waiting' || a.status === 'checked_in')
    .sort(
      (a, b) =>
        b.is_urgent - a.is_urgent ||
        a.queue_order - b.queue_order ||
        a.token_number - b.token_number
    );

  const completed = appointments
    .filter((a) => a.status === 'completed')
    .sort((a, b) => b.token_number - a.token_number);

  const skipped = appointments.filter((a) => a.status === 'skipped');

  const currentTokenNumber = activeAppointment
    ? activeAppointment.token_number
    : completed[0]?.token_number ?? null;

  const maxToken = appointments.reduce(
    (max, a) => (a.token_number > max ? a.token_number : max),
    0
  );

  const delayMinutes = Math.max(0, session.delay_minutes);
  const breakPenalty =
    session.status === 'on_break' ? Math.max(10, session.break_minutes || 10) : 0;

  const computedMap = new Map<string, ComputedAppointmentState>();

  if (activeAppointment) {
    computedMap.set(activeAppointment.id, {
      appointment: activeAppointment,
      queuePosition: 0,
      patientsAhead: 0,
      estimatedWaitMinutes: 0,
    });
  }

  // Patients ahead includes the currently active (called / in_consultation) patient if one exists
  const activeOffset = activeAppointment ? 1 : 0;

  orderedWaiting.forEach((appt, idx) => {
    const patientsAhead = idx + activeOffset;
    const queuePosition = idx + 1;
    const rawWait = patientsAhead * ewmaMinutes + delayMinutes + breakPenalty;
    const estimatedWaitMinutes = Math.max(0, Math.round(rawWait));

    computedMap.set(appt.id, {
      appointment: appt,
      queuePosition,
      patientsAhead,
      estimatedWaitMinutes,
    });
  });

  for (const appt of appointments) {
    if (!computedMap.has(appt.id)) {
      computedMap.set(appt.id, {
        appointment: appt,
        queuePosition: null,
        patientsAhead: 0,
        estimatedWaitMinutes: null,
      });
    }
  }

  return {
    session,
    doctor,
    clinic,
    ewmaMinutes,
    currentTokenNumber,
    activeAppointment,
    waitingCount: orderedWaiting.length,
    completedCount: completed.length,
    skippedCount: skipped.length,
    nextTokenNumber: maxToken + 1,
    orderedWaiting,
    computedMap,
  };
}

export function evaluateAndTriggerAlerts(
  db: Database.Database,
  sessionId: string
): Array<{ patientId: string; appointmentId: string; type: string }> {
  const summary = computeSessionQueueState(db, sessionId);
  if (!summary) return [];

  const createdAlerts: Array<{ patientId: string; appointmentId: string; type: string }> = [];
  const now = new Date().toISOString();

  const checkExisting = db.prepare(
    'SELECT id FROM notifications WHERE appointment_id = ? AND type = ? LIMIT 1'
  );
  const insertNotif = db.prepare(`
    INSERT INTO notifications (id, patient_id, appointment_id, type, channel, title, message, is_read, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)
  `);

  // Alert if patient is called
  if (
    summary.activeAppointment &&
    summary.activeAppointment.status === 'called'
  ) {
    const existingCalled = checkExisting.get(
      summary.activeAppointment.id,
      'called'
    );
    if (!existingCalled) {
      insertNotif.run(
        makeId('notif'),
        summary.activeAppointment.patient_id,
        summary.activeAppointment.id,
        'called',
        'Simulated SMS & Push',
        'Your token is being called now',
        `Token #${summary.activeAppointment.token_number} with ${summary.doctor.name} is now called to ${summary.doctor.room_number} (${summary.clinic.name}).`,
        now
      );
      createdAlerts.push({
        patientId: summary.activeAppointment.patient_id,
        appointmentId: summary.activeAppointment.id,
        type: 'called',
      });
    }
  }

  // Alert when patient is 2 positions away (or 1-2 positions away if newly entering threshold)
  for (const appt of summary.orderedWaiting) {
    const state = summary.computedMap.get(appt.id);
    if (!state) continue;
    if (state.patientsAhead <= 2 && state.patientsAhead >= 1) {
      const existingTwoAway = checkExisting.get(appt.id, 'two_away');
      if (!existingTwoAway) {
        const posLabel =
          state.patientsAhead === 1 ? '1 position away' : '2 positions away';
        insertNotif.run(
          makeId('notif'),
          appt.patient_id,
          appt.id,
          'two_away',
          'Simulated SMS & Push',
          `Almost your turn — ${posLabel}`,
          `Token #${appt.token_number} with ${summary.doctor.name} (${summary.clinic.name}) is now ${posLabel}. Estimated wait: ~${state.estimatedWaitMinutes ?? 0} min.`,
          now
        );
        createdAlerts.push({
          patientId: appt.patient_id,
          appointmentId: appt.id,
          type: 'two_away',
        });
      }
    }
  }

  return createdAlerts;
}
